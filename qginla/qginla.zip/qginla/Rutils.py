from qgis.PyQt.QtCore import *
from qgis.PyQt.QtWidgets import QToolButton, QAction, QSizePolicy, QProgressBar
from qgis.core import Qgis,QgsProject
from qgis.utils import iface
from typing import Optional
import time
import os
import os.path as op
from qgis.core import QgsVectorLayer
import tempfile
import platform
import subprocess
import sys
from typing import Optional
from ctypes import cdll
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (Qgis)
from processing.core.ProcessingConfig import ProcessingConfig
from processing.tools.system import userFolder, mkdir




class RUtils:  # pylint: disable=too-many-public-methods
    """
    Utilities for the R Provider and Algorithm
    """

    R_FOLDER = 'R_FOLDER'
    R_USE64 = 'R_USE64'

    @staticmethod
    def is_windows() -> bool:
        """
        Returns True if the plugin is running on Windows
        """
        return os.name == 'nt'

    @staticmethod
    def is_macos() -> bool:
        """
        Returns True if the plugin is running on MacOS
        """
        return platform.system() == 'Darwin'

    @staticmethod
    def r_binary_folder() -> str:
        """
        Returns the folder (hopefully) containing R binaries
        """
        folder = ProcessingConfig.getSetting(RUtils.R_FOLDER)
        #print('folder',folder)
        if not folder:
            folder = RUtils.guess_r_binary_folder()

        print('folder',os.path.abspath(folder) if folder else '')

        return os.path.abspath(folder) if folder else ''

    @staticmethod
    def guess_r_binary_folder() -> str:
        """
        Tries to pick a reasonable path for the R binaries to be executed from
        """
        if RUtils.is_macos():
            return '/usr/local/bin'

        if RUtils.is_windows():
            search_paths = ['ProgramW6432', 'PROGRAMFILES(x86)', 'PROGRAMFILES', 'C:\\']
            r_folder = ''
            for path in search_paths:
                if path in os.environ and os.path.isdir(
                        os.path.join(os.environ[path], 'R')):
                    r_folder = os.path.join(os.environ[path], 'R')
                    break

            if r_folder:
                sub_folders = os.listdir(r_folder)
                sub_folders.sort(reverse=True)
                for sub_folder in sub_folders:
                    if sub_folder.upper().startswith('R-'):
                        return os.path.join(r_folder, sub_folder)

        # expect R to be in OS path
        return ''

    @staticmethod
    def get_windows_code_page():
        """
        Determines MS-Windows CMD.exe shell codepage.
        Used into GRASS exec script under MS-Windows.
        """
        return str(cdll.kernel32.GetACP())

    @staticmethod
    def get_process_startup_info():
        """
        Returns the correct startup info to use when calling commands for different platforms
        """
        # For MS-Windows, we need to hide the console window.
        si = None
        if RUtils.is_windows():
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = subprocess.SW_HIDE
        return si

    @staticmethod
    def get_process_keywords():
        """
        Returns the correct process keywords dict to use when calling commands for different platforms
        """
        kw = {}
        if RUtils.is_windows():
            kw['startupinfo'] = RUtils.get_process_startup_info()
            if sys.version_info >= (3, 6):
                kw['encoding'] = "cp{}".format(RUtils.get_windows_code_page())
        return kw

    @staticmethod
    def path_to_r_executable(script_executable=False) -> str:
        """
        Returns the path to the R executable
        """
        executable = 'Rscript' if script_executable else 'R'
        bin_folder = RUtils.r_binary_folder()
        if bin_folder:
            if RUtils.is_windows():
                if ProcessingConfig.getSetting(RUtils.R_USE64):
                    exec_dir = 'x64'
                else:
                    exec_dir = 'i386'
                return os.path.join(bin_folder, 'bin', exec_dir, '{}.exe'.format(executable))
            return os.path.join(bin_folder, executable)

        return executable

    @staticmethod
    def check_r_is_installed() -> Optional[str]:
        """
        Checks if R is installed and working. Returns None if R IS working,
        or an error string if R was not found.
        """
        if RUtils.is_windows():
            path = RUtils.r_binary_folder()
            print('path',path)
            if path == '':
                return RUtils.tr('R folder is not configured.\nPlease configure '
                                 'it before running R scripts.')

        #command = [RUtils.path_to_r_executable(), '--version']
        #print('command',command)
        command = 'C:\\Program Files\\R\\R-4.3.1\\bin\\R.exe'
        print('command',command)
        #try:
        with subprocess.Popen(command,
                              stdout=subprocess.PIPE,
                              stdin=subprocess.DEVNULL,
                              stderr=subprocess.STDOUT,
                              universal_newlines=True,
                              **RUtils.get_process_keywords()) as proc:
            for line in proc.stdout:
                print('line',line)
                if ('R version' in line) or ('R Under development' in line):
                    return None
        # except FileNotFoundError:
        #     print('error')
            pass

        html = RUtils.tr(
            '<p>This algorithm requires R to be run. Unfortunately, it '
            'seems that R is not installed in your system, or it is not '
            'correctly configured to be used from QGIS</p>'
            '<p><a href="http://docs.qgis.org/testing/en/docs/user_manual/processing/3rdParty.html">Click here</a> '
            'to know more about how to install and configure R to be used with QGIS</p>')

        return html

    @staticmethod
    def tr(string, context=''):
        """
        Translates a string
        """
        if context == '':
            context = 'RUtils'
        return QCoreApplication.translate(context, string)

    def canExecute():
        """
        Returns True if the algorithm can be executed
        """

        msg = RUtils.check_r_is_installed()
        print(msg,'msg')
        if msg is not None:
            return False, msg

        return True, ''
    
