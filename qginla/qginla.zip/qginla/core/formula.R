# script.R

myhypertau=function(a,b) {
    myh=paste0("hyper = list(prec = list(prior='loggamma',param=c(",a, ",",b,")))")
    return(myh)
}
myhyperbym2=function(a,b,c,d) {
    myh=paste0("hyper = list(prec = list(prior='pc',initial=5, param=c(",a, ",",b,")), phi = list(prior='pc', initial=-3, param=c(",c, ",",d,")))")
    return(myh)
}
myhyperbym=function(a,b,c,d) {
    myh=paste0("hyper = list(prec.unstruct = list(prior='loggamma',param=c(",a, ",",b,")), prec.spatial = list(prior='loggamma',param=c(",c, ",",d,")))")
    return(myh)
}

createf3besag <- function(var='var', model='model', graph=NULL,a=a,b=b,c=NULL,d=NULL){
    myf <- paste0("f(", var ,",model='besag',scale.model =TRUE, adjust.for.con.comp = TRUE, graph=inla.read.graph(filename = '", graph,"')," ,myhypertau(a,b),")")
    return(myf)
}

createf3bym <- function(var='var', model='model', graph=NULL,a=a,b=b,c=NULL,d=NULL){
    myf <- paste0("f(", var ,",model='bym',scale.model =TRUE, adjust.for.con.comp = TRUE, graph=inla.read.graph(filename = '", graph,"'),",myhyperbym(a,b,c,d), ")")
    return(myf)
}

createf3bym2 <- function(var='var', model='model', graph=NULL,a=a,b=b,c=NULL,d=NULL){
    myf <- paste0("f(", var ,",model='bym2',scale.model =TRUE, adjust.for.con.comp = TRUE, graph=inla.read.graph(filename = '", graph,"'),",myhyperbym2(a,b,c,d), ")")
    return(myf)
}

createf3rw1 <- function(var='var', model='model', graph=NULL,a=a,b=b,c=NULL,d=NULL){
    myf <- paste0("f(", var, ",model='rw1',", myhypertau(a,b),")" )
    return(myf)
}

createf3iid <- function(var='var', model='model', graph=NULL,a=a,b=b,c=NULL,d=NULL){
    myf <- paste0("f(", var, ",model='iid',", myhypertau(a,b),")" )
    return(myf)
}

createf3Siid <- function(var='var', model='model', graph=NULL,a=a,b=b,c=NULL,d=NULL){
    myf <- paste0("f(", var ,",model='iid',", myhypertau(a,b),")" )
    return(myf)
}


formula <- function(f_terms,y_outcome,data,family,offset){
    t1=reformulate( f_terms, response=y_outcome)
    print(t1)
    if (family=='poisson'){
        mod.INLA = inla(formula = t1, 
                        family = family, 
                        offset = offset,
                        data = data,
                        control.inla = list(int.strategy = "eb"),
                        control.predictor = list(compute = T),
                        verbose = T)
    } else if (family=='gaussian'){
        mod.INLA = inla(formula = t1, 
                        family = family, 
                        data = data,
                        control.inla = list(int.strategy = "eb"),
                        control.predictor = list(compute = T),
                        verbose = T)
    } else{
        mod.INLA = inla(formula = t1, 
                        family = family, 
                        Ntrial = 1,
                        data = data,
                        control.inla = list(int.strategy = "eb"),
                        control.predictor = list(compute = T),
                        verbose = T)
    }
  
  
    return(list(mod.INLA$summary,
        mod.INLA$summary.fixed,
        mod.INLA$summary.random,
        mod.INLA$summary.fitted.values,
        mod.INLA$summary.linear.predictor
    ))
}