# -*- coding: utf-8 -*-
"""
/***************************************************************************
 QGINLA
                                 A QGIS plugin
 INLA for QGIS
                             -------------------
        begin                : 2023-07-01
        copyright            : (C) 2023 by giacomo titti
        email                : giacomo.titti@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import numpy as np
import os.path as op
import pandas as pd
import rpy2.robjects as robjects
from rpy2.robjects import pandas2ri
from rpy2.robjects.packages import SignatureTranslatedAnonymousPackage
from sklearn.preprocessing import scale
from qginla.utils import utils
import matplotlib.pyplot as plt
class MyCode:

    def __init__(self, gdf):

        self.pathFormula=op.join(op.dirname(__file__), 'formula.R')

        self.gdf=gdf

        #ID gen
        gdf,self.ID_column = utils.ID_generator(gdf)
        #ID2 gen
        #self.gdf,self.IDunstr_column = utils.graph_ID_generator(gdf)

        # variables required for using the algorithm inside a UI
        self.set_progress = None
        self.print_log = None
    
    def find_key(self,dictionary, target_value):
        """List parameters"""
        for key, value in dictionary.items():
            if value == target_value:
                return True
            elif isinstance(value, dict):
                nested_result = self.find_key(value, target_value)
                if nested_result:
                    return True
        return False
    
    def plotfixed(self,fixed,cov_fields):
        """Plot fixed effetct"""

        plt.figure('fixed')
        plt.gca().set_facecolor((0.8, 0.8, 0.8, 0.3))
        plt.grid(color='white', linestyle='dashed')
        plt.scatter(fixed.index[1:],fixed['mean'][1:], c='blue', label='mean', marker='o')
        plt.scatter(fixed.index[1:],fixed['0.025quant'][1:], c='gray', label='2.5th', marker='o')
        plt.scatter(fixed.index[1:],fixed['0.975quant'][1:], c='gray', label='97.5th', marker='o')
        plt.axhline(y=0, c='black')
        plt.xlabel('Fixed effects')
        plt.ylabel('Regression coefficient')
        plt.legend()
        plt.show()
            
    def plotrandom(self,random,cov_fields): 
        """Plot random effects"""

        count=0
        names=list(random.names)
        for var in random:
            if names[count]==self.ID_column:
                continue
            if cov_fields[names[count]]['type']=='rw1':
                plt.figure('random_'+names[count])
                plt.gca().set_facecolor((0.8, 0.8, 0.8, 0.3))
                plt.grid(color=(1, 1, 1,0.5), linestyle='dashed')
                plt.plot(var.index[1:],var['mean'][1:], c='blue', label='mean')
                plt.plot(var.index[1:],var['0.025quant'][1:], c='gray', label='2.5th')
                plt.plot(var.index[1:],var['0.975quant'][1:], c='gray', label='97.5th')
                plt.axhline(y=0, c='black')
                plt.fill_between(var.index[1:], var['0.025quant'][1:], var['0.975quant'][1:], color='gray', alpha=0.5)
                plt.xlabel('Random effects')
                plt.ylabel('Regression coefficient')
                plt.xticks(range(1, len(var.index[1:]) , 2))  # Set x-axis ticks to [1, 3, 5, 7, 9]
                plt.legend()
                plt.show()
            if cov_fields[names[count]]['type']=='iid':
                plt.figure('random_'+names[count])
                plt.gca().set_facecolor((0.8, 0.8, 0.8, 0.3))
                plt.grid(color=(1, 1, 1,0.5), linestyle='dashed')
                plt.scatter(var.index[1:],var['mean'][1:], c='blue', label='mean', marker='o')
                plt.scatter(var.index[1:],var['0.025quant'][1:], c='gray', label='2.5th', marker='o')
                plt.scatter(var.index[1:],var['0.975quant'][1:], c='gray', label='97.5th', marker='o')
                plt.axhline(y=0, c='black', linestyle='dashed')
                plt.xlabel('Random effects')
                plt.ylabel('Regression coefficient')
                plt.xticks(range(1, len(var.index[1:]) , 2))  # Set x-axis ticks to [1, 3, 5, 7, 9]
                plt.legend()
                plt.show()

            count+=1
    
    def merge_dataframes(self, ID, df, gdf):
        """Reconstruct the geometries of input vector"""
        columnnames=df.columns.tolist()
        columnnames=columnnames[1:]
        columnnames.append('geometry')
        columnnames.append(ID)
        df[ID]=list(gdf[ID])
        gdf_merged = gdf.merge(df, on=ID)
        gdf_merged=gdf_merged[columnnames]
        return gdf_merged

    
    def execute(self,y_field, cov_fields, scale_method,family,offset, set_progress: callable = None,log: callable = print):
        """Execute the run"""

        self.set_progress = set_progress if set_progress else printProgress
        self.print_log = log if log else print

        self.print_log('-------------------------------------------------------------Start analysis-------------------------------------------------------------')
        self.set_progress(0)

        with open(self.pathFormula, 'r') as file:
            script_code = file.read()
        
        # Create the anonymous R package
        r_package = SignatureTranslatedAnonymousPackage(script_code, "r_package")
        
        try:
            columns=list(cov_fields.keys())
            columns.remove('smooth')
        except:
            columns=list(cov_fields.keys())
                
        #scale the values
        columns_to_scale=columns
        gdf_scaled=utils.to_scale(self.gdf,columns_to_scale,scale_method)
        self.print_log('Covariate scaled')
        self.set_progress(10)

        #remove rows with NaN 
        columns_to_check=columns
        columns.append(self.ID_column)
        gdf_scaled_dropna=utils.to_drop_nan(gdf_scaled,columns_to_check)
        self.print_log('Null values deleted')
        self.set_progress(20)

        #build graph object
        g_path=utils.graph_calculator(gdf_scaled_dropna,self.ID_column)
        
        self.set_progress(30)

        # convert the GeoDataFrame to a Pandas DataFrame
        df = gdf_scaled_dropna.drop("geometry", axis=1)

        #select columns (covariates) from input vector
        columns_selected=columns+[y_field]
        self.df = df[columns_selected]

        #list of covariates
        random_var=[]
        for key,value in cov_fields.items():
            if self.find_key(cov_fields[key], 'random'):
                random_var.append(key)
        
        fixed_var=[]
        for key,value in cov_fields.items():
            if self.find_key(cov_fields[key], 'fixed'):
                fixed_var.append(key)

        #start to build the formula - fixed effects
        formula = fixed_var

        for item in random_var:  
            if cov_fields[item]['type']=='iid':
                random_f=r_package.createf3iid(var=item, model=cov_fields[item]['type'], graph=g_path, a=cov_fields[item]['hyp1'], b=cov_fields[item]['hyp2'])
            if cov_fields[item]['type']=='rw1':
                random_f=r_package.createf3rw1(var=item, model=cov_fields[item]['type'], graph=g_path, a=cov_fields[item]['hyp1'], b=cov_fields[item]['hyp2'])
            formula = formula + [robjects.r['as.character'](random_f)[0]]
        
        if 'smooth' in list(cov_fields):
            print(cov_fields,'items')
            item='smooth'
            if cov_fields[item]['type']=='bym':
                random_f=r_package.createf3bym(var=self.ID_column, model=cov_fields[item]['type'], graph=g_path, a=cov_fields[item]['hyp1'], b=cov_fields[item]['hyp2'], c=cov_fields[item]['hyp3'], d=cov_fields[item]['hyp4'])
            elif cov_fields[item]['type']=='bym2':
                random_f=r_package.createf3bym2(var=self.ID_column, model=cov_fields[item]['type'], graph=g_path, a=cov_fields[item]['hyp1'], b=cov_fields[item]['hyp2'], c=cov_fields[item]['hyp3'], d=cov_fields[item]['hyp4'])
            elif cov_fields[item]['type']=='besag':
                random_f=r_package.createf3besag(var=self.ID_column, model=cov_fields[item]['type'], graph=g_path, a=cov_fields[item]['hyp1'], b=cov_fields[item]['hyp2'])
            elif cov_fields[item]['type']=='Siid':
                random_f=r_package.createf3Siid(var=self.ID_column, model=cov_fields[item]['type'], graph=g_path,a=cov_fields[item]['hyp1'], b=cov_fields[item]['hyp2'])

            #start to build the formula - random effects
            formula = formula + [robjects.r['as.character'](random_f)[0]]
        
        self.print_log('INLA start run')
        self.set_progress(40)

        #convert pandas dataframe to R dataframe
        pandas2ri.activate()
        data=pandas2ri.py2rpy(self.df) 

        #run INLA formula in R
        [INLA,fixed,random,fittedvalues,linearpredictor]=r_package.formula(robjects.StrVector(formula),y_field,data,family,offset)

        #prepare output layers
        #convert pandas dataframe into geopandas dataframe
        if len(fittedvalues)!=0:
            gdf_fittedvalues = self.merge_dataframes(self.ID_column,fittedvalues,gdf_scaled_dropna)
        else:
            gdf_fittedvalues=None

        if len(linearpredictor)!=0:
            gdf_linearpredictor = self.merge_dataframes(self.ID_column,linearpredictor,gdf_scaled_dropna)
        else:
            gdf_linearpredictor=None

        if len(random)!=0:
            count=0
            for var in random:
                var=pd.DataFrame(var)
                if 'smooth' in list(cov_fields):
                    item='smooth'
                    if cov_fields[item]['type']=='bym' or cov_fields[item]['type']=='bym2':
                        gdf_latenteffect_half1 = self.merge_dataframes(self.ID_column,var.iloc[0:int(len(var)/2)],gdf_scaled_dropna)
                        gdf_latenteffect_half2 = self.merge_dataframes(self.ID_column,var.iloc[int(len(var)/2):int(len(var))],gdf_scaled_dropna)
                        gdf_latenteffect=[gdf_latenteffect_half1,gdf_latenteffect_half2]
                    else:
                        gdf_latenteffect = [self.merge_dataframes(self.ID_column,var,gdf_scaled_dropna)]                     
                count+=1
        else:
            gdf_latenteffect=None

        #choose the plot according to the formula
        if len(fixed)!=0:
            self.plotfixed(fixed,cov_fields)
        if len(random)!=0:
            self.plotrandom(random,cov_fields)

        self.print_log('INLA ended')
        self.set_progress(90)
        self.print_log('-------------------------------------------------------------End analysis-------------------------------------------------------------')
       
        return([INLA,fixed,random,gdf_fittedvalues,gdf_linearpredictor,gdf_latenteffect])

def printProgress(value: int):
    """ Replacement for the GUI progress bar """
    print('progress: {} %'.format(value))