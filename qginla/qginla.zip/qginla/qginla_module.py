# -*- coding: utf-8 -*-
"""
/***************************************************************************
 QGINLA
                                 A QGIS plugin
 INLA for QGIS
                             -------------------
        begin                : 2023-07-01
        copyright            : (C) 2023 by giacomo titti
        email                : giacomo.titti@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
from os import path
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMenu
from qgis.PyQt.QtCore import QSettings
from qgis.core import QgsApplication
from qginla.images.cqp_resources_rc import qInitResources
qInitResources()  # necessary to be able to access your images
from .installer.installer import installer
from .utils import log,warn,load_env_file
import inspect
import sys

cmd_folder = os.path.split(inspect.getfile(inspect.currentframe()))[0]

if cmd_folder not in sys.path:
    sys.path.insert(0, cmd_folder)

class qginla_class:
    """ QGIS Plugin Implementation """

    def __init__(self, iface):
        # Save reference to the QGIS interface
        self.iface = iface

        # initialize plugin directory
        self.plugin_dir = path.dirname(__file__)

        # Add an empty menu to the toolbar
        self.toolbar = self.iface.addToolBar('QGINLA')
        self.toolbar.setObjectName('toolbar_QGINLA')

        # Add an empty menu to the plugin Menu
        self.main_menu = QMenu(title='QGINLA menu', parent=self.iface.pluginMenu())
        self.main_menu.setIcon(QIcon(':/qginla_logo'))
        self.iface.pluginMenu().addMenu(self.main_menu)
        self.provider = None

        dir=(os.path.dirname(os.path.abspath(__file__)))
        load_env_file(os.path.join(dir, ".env"))
        with open(dir+'/metadata.txt','r') as file:
            for line in file:
                if line.startswith('version='):
                    long_version = line.strip().split('version=')[1].strip()
                    self.version = '.'.join(long_version.split('.')[:-1])
        self.plugin_settings = QSettings().value("QGINLA",False)

    def initGui(self):
        self.installer=installer(self.version,self.plugin_settings)
        print('Plugin already installed? ',self.plugin_settings)
        #if not self.plugin_settings.value("installed"):# or self.plugin_settings.value("active"):
        print('0')
        #if os.environ.get('DEBUG')=='False':
        if self.installer.preliminay_req() is False:
            self.installer.unload()
            log(f"An error occured during the installation")
            raise RuntimeError("An error occured during the installation")
        else:
            if self.installer.is_already_installed(self.version) is False:
                if self.installer.requirements() is False:
                    self.installer.unload()
                    log(f"An error occured during the installation")
                    raise RuntimeError("An error occured during the installation")
                else:
                    QSettings().setValue("QGINLA", str(self.version))
                    #self.initProcessing() 

        package_name = ["INLA"]#,"spdep"]###add packages for R to be installed
        #self.installer.R_requirements(package_name)
         
        # add action button to toolbar
        action_toolbar = QAction(self.toolbar)
        action_toolbar.setText("QGINLA")
        action_toolbar.setIcon(QIcon(':/qginla_logo'))
        action_toolbar.triggered.connect(self.run_widget)

        self.toolbar.addAction(action_toolbar)

        # add action button to plugin menu
        action = QAction(QIcon(':/qginla_logo'), 'QGINLA', self.iface.mainWindow())
        action.triggered.connect(self.run_widget)
        action.setStatusTip('Quick information on your plugin.')
        
        self.main_menu.addAction(action)

        # check processing provider
        if os.getenv('PROCESSING_PROVIDER')=='True':
            # add provider to processing toolbox
            self.provider = MyProcessingProvider()
            QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        self.iface.pluginMenu().removeAction(self.main_menu.menuAction())

        # check processing provider
        if os.getenv('PROCESSING_PROVIDER')=='True':
            QgsApplication.processingRegistry().removeProvider(self.provider)

    @staticmethod
    def run_widget(self):
        from .interfaces.gui import TheWidget
        widget = TheWidget()
        widget.show()
        widget.exec_()
