# -*- coding: utf-8 -*-
"""
/***************************************************************************
 QGINLA
                                 A QGIS plugin
 INLA for QGIS
                             -------------------
        begin                : 2023-07-01
        copyright            : (C) 2023 by giacomo titti
        email                : giacomo.titti@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

from typing import Optional
from qgis.PyQt.QtCore import *
from qgis.PyQt.QtWidgets import QToolButton, QAction, QSizePolicy, QProgressBar
from qgis.core import Qgis,QgsProject
from qgis.utils import iface
import time
import os
import os.path as op
from osgeo import gdal
from qgis.core import QgsVectorLayer
from sklearn.preprocessing import scale, MinMaxScaler
import geopandas as gpd
import pandas as pd
from libpysal.weights import Rook
import tempfile
import platform
import re
import subprocess
import sys
from typing import Optional
from ctypes import cdll
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (QgsProcessingUtils,
                       QgsMessageLog,
                       Qgis)
from processing.core.ProcessingConfig import ProcessingConfig
from processing.tools.system import userFolder, mkdir

class MessageHandler(QObject):
    """Some useful functions for messages"""
    messageLevel = [Qgis.Info, Qgis.Warning, Qgis.Critical, Qgis.Success]

    messageTime = iface.messageTimeout()

    @staticmethod
    def information(title: Optional[str] = "",
                    text: Optional[str] = "",
                    timeout: Optional[int] = 0) -> None:
        """Function used to display an information message"""

        level = MessageHandler.messageLevel[0]
        if timeout:
            timeout = MessageHandler.messageTime
        MessageHandler.messageBar(title, text, level, timeout)

    @staticmethod
    def warning(title: Optional[str] = "",
                text: Optional[str] = "",
                timeout: Optional[int] = 0) -> None:
        """Function used to display a warning message
        """
        level = MessageHandler.messageLevel[1]
        if timeout:
            timeout = MessageHandler.messageTime
        MessageHandler.messageBar(title, text, level, timeout)

    @staticmethod
    def critical(title: Optional[str] = "",
                 text: Optional[str] = "",
                 timeout: Optional[int] = 0) -> None:
        """Function used to display a critical message
        """
        level = MessageHandler.messageLevel[2]
        if timeout:
            timeout = MessageHandler.messageTime
        MessageHandler.messageBar(title, text, level, timeout)

    @staticmethod
    def success(title: Optional[str] = "",
                text: Optional[str] = "",
                timeout: Optional[int] = 0) -> None:
        """Function used to display a succeded message
        """
        level = MessageHandler.messageLevel[3]
        if timeout:
            timeout = MessageHandler.messageTime
        MessageHandler.messageBar(title, text, level, timeout)

    @staticmethod
    def error(message: str) -> None:
        """Function used to display an error message
        """
        button = QToolButton()
        action = QAction(button)
        action.setText("Apri finestra dei logs")
        button.setCursor(Qt.PointingHandCursor)
        button.setStyleSheet(
            "background-color: rgba(255, 255, 255, 0); color: black; "
            "text-decoration: underline;")
        button.setSizePolicy(QSizePolicy.Maximum, QSizePolicy.Preferred)
        button.addAction(action)
        button.setDefaultAction(action)
        button.clicked.connect(iface.openMessageLog)
        widgetBar = iface.messageBar().createMessage(message)
        widgetBar.layout().addWidget(button)
        iface.messageBar().pushWidget(widgetBar,
                                      MessageHandler.messageLevel[3])

    @staticmethod
    def messageBar(title: str, text: str, level: int, timeout: int) -> None:
        if title:
            try:
                iface.messageBar().pushMessage(title.decode('utf-8'),
                                               text.decode('utf-8'), level,
                                               timeout)
            except Exception:
                iface.messageBar().pushMessage(title, text, level, timeout)
        else:
            try:
                iface.messageBar().pushMessage(text.decode('utf-8'), level,
                                               timeout)
            except Exception:
                iface.messageBar().pushMessage(str(text), level, timeout)
    
    @staticmethod
    def fake_progress(text: Optional[str] = "") -> None:
        """Function used to display a warning message
        """   
        progressMessageBar = MessageHandler.messageBar().createMessage(text.decode('utf-8'))
        progress = QProgressBar()
        progress.setMaximum(10)
        progressMessageBar.layout().addWidget(progress)
        iface.messageBar().pushWidget(progressMessageBar)

        for i in range(1):
            time.sleep(1)
            progress.setValue(i + 5)

class utils:
    """Some useful functions for QGINLA"""

    @staticmethod
    def import_vector(path) -> tuple:
        """Import vector as QgsVectorLayer"""

        if not os.path.exists(path):
            raise Exception("Cannot find file '" + path + "'.")

        try:
            # read the shapefile as a GeoDataFrame
            gdf = gpd.read_file(path)
            
            vlayer=QgsVectorLayer(path, os.path.splitext(op.basename(path))[0], 'ogr')
            metadata = {'crs': vlayer.sourceCrs(), 'extent': vlayer.sourceExtent}

            return gdf, vlayer, metadata

        except Exception as e:
            raise Exception(str(e))

    @staticmethod
    def to_scale(df,columns_to_scale, scale_method) -> pd.DataFrame:
        """Scale covariates"""

        if scale_method=='zero':
            # Scale the dataframe columns
            df[columns_to_scale]=scale(df[columns_to_scale])
            return(df)
        elif scale_method=='minmax':
            df[columns_to_scale]=MinMaxScaler().fit_transform(df[columns_to_scale])
            return(df)
        
    @staticmethod
    def to_drop_nan(df,columns_to_check) -> pd.DataFrame:
        """Drop rows with NaN value"""

        df.dropna(subset=columns_to_check)
        return df
    
    @staticmethod
    def ID_generator(df) -> pd.DataFrame:
        """Generate column ID"""

        df.insert(0, 'ID_code', range(1, len(df)+1))
        IDcolumn='ID_code'
        return(df,IDcolumn)
    
    # @staticmethod
    # def graph_ID_generator(df) -> pd.DataFrame:
    #     df.insert(0, 'ID_unstruc', range(1, len(df)+1))
    #     IDcolumn='ID_unstruc'
    #     return(df,IDcolumn)

    @staticmethod
    def graph_calculator(gdf,idcolumn):
        """Build graph object"""
        
        w_rook = Rook.from_dataframe(gdf,ids=idcolumn)
        output_file = op.join(tempfile.gettempdir(), 'graph.adj')
        with open(output_file, 'w') as f:
            f.write(f"{len(w_rook.neighbors.items())}\n")
            for node, neighbors in w_rook.neighbors.items():
                neighbors.sort()
                num=len([str(int(num)) for num in neighbors])
                numbers_str = f"{int(node)}"+" "+str(num)+" "+(' '.join(str(int(num)) for num in neighbors))
                line = f"{numbers_str}\n"
                if len(numbers_str)==0:
                    continue
                else:
                    f.write(line)
        return output_file
    
    @staticmethod
    def load_vector_to_canvas(path,name):
        """Load layer in map canvas"""
        
        output_layer = QgsVectorLayer(path, name)
        QgsProject.instance().addMapLayer(output_layer, True)

    #def graph_ID_generator(df) -> pd.DataFrame:
    #    df.insert(0, 'ID_unstruc', range(0, len(df)))
    #    return(df)

class RUtils:  # pylint: disable=too-many-public-methods
    """
    Utilities for the R Provider and Algorithm
    """

    RSCRIPTS_FOLDER = 'R_SCRIPTS_FOLDER'
    R_FOLDER = 'R_FOLDER'
    R_USE64 = 'R_USE64'
    R_LIBS_USER = 'R_LIBS_USER'
    R_USE_USER_LIB = 'R_USE_USER_LIB'
    R_REPO = 'R_REPO'

    VALID_CHARS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'

    @staticmethod
    def is_windows() -> bool:
        """
        Returns True if the plugin is running on Windows
        """
        return os.name == 'nt'

    @staticmethod
    def is_macos() -> bool:
        """
        Returns True if the plugin is running on MacOS
        """
        return platform.system() == 'Darwin'

    @staticmethod
    def r_binary_folder() -> str:
        """
        Returns the folder (hopefully) containing R binaries
        """
        folder = ProcessingConfig.getSetting(RUtils.R_FOLDER)
        if not folder:
            folder = RUtils.guess_r_binary_folder()

        return os.path.abspath(folder) if folder else ''

    @staticmethod
    def guess_r_binary_folder() -> str:
        """
        Tries to pick a reasonable path for the R binaries to be executed from
        """
        if RUtils.is_macos():
            return '/usr/local/bin'

        if RUtils.is_windows():
            search_paths = ['ProgramW6432', 'PROGRAMFILES(x86)', 'PROGRAMFILES', 'C:\\']
            r_folder = ''
            for path in search_paths:
                if path in os.environ and os.path.isdir(
                        os.path.join(os.environ[path], 'R')):
                    r_folder = os.path.join(os.environ[path], 'R')
                    break

            if r_folder:
                sub_folders = os.listdir(r_folder)
                sub_folders.sort(reverse=True)
                for sub_folder in sub_folders:
                    if sub_folder.upper().startswith('R-'):
                        return os.path.join(r_folder, sub_folder)

        # expect R to be in OS path
        return ''

    @staticmethod
    def get_windows_code_page():
        """
        Determines MS-Windows CMD.exe shell codepage.
        Used into GRASS exec script under MS-Windows.
        """
        return str(cdll.kernel32.GetACP())

    @staticmethod
    def get_process_startup_info():
        """
        Returns the correct startup info to use when calling commands for different platforms
        """
        # For MS-Windows, we need to hide the console window.
        si = None
        if RUtils.is_windows():
            si = subprocess.STARTUPINFO()
            si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            si.wShowWindow = subprocess.SW_HIDE
        return si

    @staticmethod
    def get_process_keywords():
        """
        Returns the correct process keywords dict to use when calling commands for different platforms
        """
        kw = {}
        if RUtils.is_windows():
            kw['startupinfo'] = RUtils.get_process_startup_info()
            if sys.version_info >= (3, 6):
                kw['encoding'] = "cp{}".format(RUtils.get_windows_code_page())
        return kw

    @staticmethod
    def path_to_r_executable(script_executable=False) -> str:
        """
        Returns the path to the R executable
        """
        executable = 'Rscript' if script_executable else 'R'
        bin_folder = RUtils.r_binary_folder()
        if bin_folder:
            if RUtils.is_windows():
                if ProcessingConfig.getSetting(RUtils.R_USE64):
                    exec_dir = 'x64'
                else:
                    exec_dir = 'i386'
                return os.path.join(bin_folder, 'bin', exec_dir, '{}.exe'.format(executable))
            return os.path.join(bin_folder, executable)

        return executable

    @staticmethod
    def check_r_is_installed() -> Optional[str]:
        """
        Checks if R is installed and working. Returns None if R IS working,
        or an error string if R was not found.
        """
        if RUtils.is_windows():
            path = RUtils.r_binary_folder()
            if path == '':
                return RUtils.tr('R folder is not configured.\nPlease configure '
                                 'it before running R scripts.')

        command = [RUtils.path_to_r_executable(), '--version']
        try:
            with subprocess.Popen(command,
                                  stdout=subprocess.PIPE,
                                  stdin=subprocess.DEVNULL,
                                  stderr=subprocess.STDOUT,
                                  universal_newlines=True,
                                  **RUtils.get_process_keywords()) as proc:
                for line in proc.stdout:
                    if ('R version' in line) or ('R Under development' in line):
                        return None
        except FileNotFoundError:
            pass

        html = RUtils.tr(
            '<p>This algorithm requires R to be run. Unfortunately, it '
            'seems that R is not installed in your system, or it is not '
            'correctly configured to be used from QGIS</p>'
            '<p><a href="http://docs.qgis.org/testing/en/docs/user_manual/processing/3rdParty.html">Click here</a> '
            'to know more about how to install and configure R to be used with QGIS</p>')

        return html

    @staticmethod
    def tr(string, context=''):
        """
        Translates a string
        """
        if context == '':
            context = 'RUtils'
        return QCoreApplication.translate(context, string)
    
    def canExecute():
        """
        Returns True if the algorithm can be executed
        """

        msg = RUtils.check_r_is_installed()
        if msg is not None:
            return False, msg

        return True, ''