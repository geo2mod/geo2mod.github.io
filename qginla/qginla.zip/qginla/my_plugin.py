# -*- coding: utf-8 -*-
"""
/***************************************************************************
 QGINLA
                                 A QGIS plugin
 INLA for QGIS
                             -------------------
        begin                : 2023-07-01
        copyright            : (C) 2023 by giacomo titti
        email                : giacomo.titti@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

import os
from os import path
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QMenu
from qgis.core import QgsApplication
from qginla.interfaces.my_gui import MyWidget
from qginla.images.cqp_resources_rc import qInitResources
qInitResources()  # necessary to be able to access your images

class MyPlugin:
    """ QGIS Plugin Implementation """

    def __init__(self, iface):
        # Save reference to the QGIS interface
        self.iface = iface

        # initialize plugin directory
        self.plugin_dir = path.dirname(__file__)

        # Add an empty menu to the toolbar
        self.toolbar = self.iface.addToolBar('QGINLA')
        self.toolbar.setObjectName('toolbar_QGINLA')

        # Add an empty menu to the plugin Menu
        self.main_menu = QMenu(title='QGINLA menu', parent=self.iface.pluginMenu())
        self.main_menu.setIcon(QIcon(':/qginla_logo'))
        self.iface.pluginMenu().addMenu(self.main_menu)
        self.provider = None

    def initGui(self):
        """ Create the menu entries and toolbar icons inside the QGIS GUI """
        
        # add action button to toolbar
        action_toolbar = QAction(self.toolbar)
        action_toolbar.setText("QGINLA")
        action_toolbar.setIcon(QIcon(':/qginla_logo'))
        action_toolbar.triggered.connect(self.run_widget)

        self.toolbar.addAction(action_toolbar)

        # add action button to plugin menu
        action = QAction(QIcon(':/qginla_logo'), 'QGINLA', self.iface.mainWindow())
        action.triggered.connect(self.run_widget)
        action.setStatusTip('Quick information on your plugin.')
        
        self.main_menu.addAction(action)

        # check processing provider
        if os.getenv('PROCESSING_PROVIDER')=='True':
            # add provider to processing toolbox
            self.provider = MyProcessingProvider()
            QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        self.iface.pluginMenu().removeAction(self.main_menu.menuAction())

        # check processing provider
        if os.getenv('PROCESSING_PROVIDER')=='True':
            QgsApplication.processingRegistry().removeProvider(self.provider)

    @staticmethod
    def run_widget():
        widget = MyWidget()
        widget.show()
        widget.exec_()
