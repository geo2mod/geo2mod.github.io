# -*- coding: utf-8 -*-
"""
/***************************************************************************
 QGINLA
                                 A QGIS plugin
 INLA for QGIS
                             -------------------
        begin                : 2023-07-01
        copyright            : (C) 2023 by giacomo titti
        email                : giacomo.titti@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""


# noinspection PyPep8Naming
def classFactory(iface):
    """ Load plugin main class """

    from dotenv import load_dotenv
    from pathlib import Path
    from qginla.utils import RUtils,MessageHandler
    import rpy2.robjects.packages as rpackages
    from qginla.my_plugin import MyPlugin
    import subprocess

    # load .env variables
    dotenv_path = Path('./.env')
    load_dotenv(dotenv_path=dotenv_path)

    # check if R is installed in your computer
    if RUtils.canExecute():
        MessageHandler.success('QGINLA: R is installed')
        pass
    else:
        MessageHandler.error('QGINLA: no R installed, please install R in your computer')

    # check if INLA library is installed in your R
    package_name = ["INLA"]#,"spdep"]###add packages for R to be installed

    for package in package_name:
        try:
            rpackages.importr(package)
            MessageHandler.success('QGINLA: '+package+' is loaded correctly')
        except:
            try:
                # Define the R script to install the INLA package
                r_script = """
                install.packages("""+ package +""",repos=c(getOption("repos"),INLA="https://inla.r-inla-download.org/R/stable"), dep=TRUE)
                """
                # Use subprocess to run the R script
                subprocess.run(['Rscript', '-e', r_script])
                MessageHandler.success('QGINLA: '+package+' is installed succesfully')
            except Exception as e:
                raise Exception(str(e))
            try:
                rpackages.importr(package)
                MessageHandler.success('QGINLA: '+package+' is loaded succesfully')
            except Exception as e:
                raise Exception(str(e))

    return MyPlugin(iface)
