# -*- coding: utf-8 -*-
"""
/***************************************************************************
 QGINLA
                                 A QGIS plugin
 INLA for QGIS
                             -------------------
        begin                : 2023-07-01
        copyright            : (C) 2023 by giacomo titti
        email                : giacomo.titti@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

__author__ = 'Giacomo Titti'
__date__ = '2024-07-01'
__copyright__ = '(C) 2024 by Giacomo Titti'

import subprocess
import os
from qgis.gui import QgsMessageBar
from qgis.core import Qgis
import sys

# noinspection PyPep8Naming
def classFactory(iface):
    """ Load plugin main class """

    # load .env variables
    loadenv()

    #from qginla.Rutils import RUtils
    ##check if R is installed in your computer
    # R,msg=RUtils.canExecute()
    # if R==True:
    #     #MessageHandler.success('QGINLA: R is installed')
    #     iface.messageBar().pushMessage("QGINLA:",'R is installed',Qgis.Success)
    # else:
    #     #MessageHandler.error('QGINLA: no R installed, please install R in your computer')
    #     iface.messageBar().pushMessage("QGINLA:",msg,Qgis.Critical)
    #     sys.exit('no R installed, please install R in your computer')


    # install requirements
    #requirements(iface)

    from qginla.utils import MessageHandler
    from pathlib import Path
    from qginla.qginla_module import qginla_class


    # check if INLA library is installed in your R
    #package_name = ["INLA"]#,"spdep"]###add packages for R to be installed
    #R_requirements(package_name)


    return qginla_class(iface)


# def requirements(iface):
#     dir=os.path.dirname(os.path.abspath(__file__))
#     with open(dir+'/requirements.txt', "r") as file:
#         for line in file:
#             parts=line.split("==")
#             try:
#                 library=parts[0]
#                 version=parts[1][:-1]
#             except:
#                 library=parts[0]
#                 version=None

#             try:
#                 exec(f"import {library}")
#                 installed_version=eval(f"{library}.__version__")
#                 if version is None:
#                     iface.messageBar().pushMessage('QGINLA:',f'{library} is installed!',Qgis.Success)
#                     #MessageHandler.success(f'QGINLA: {library} is installed!')
#                 else:
#                     print(installed_version,version)
#                     if str(installed_version)==str(version):
#                         iface.messageBar().pushMessage("QGINLA:",f'{library} is installed!',Qgis.Success)
#                         #MessageHandler.success(f'QGINLA: {library} is installed!')
#                     else:
#                         iface.messageBar().pushMessage("QGINLA:",f'{library} is already installed but the actual version '+f'({installed_version}) is different than the required ({version}). It may cause errors!',Qgis.Warning)
#                         #MessageHandler.warning(f'QGINLA: {library} is already installed but the actual version '+f'({installed_version}) is different than the required ({version}). It may cause errors!')

#             except ImportError:
#                 iface.messageBar().pushMessage("QGINLA:",f'installing {library}...',Qgis.Info, duration=5)


#                 # Define the command you want to run
#                 if version is None:
#                     command = ['pip', 'install', library]
#                 else:
#                     command = ['pip', 'install', library+'=='+version]
#                 # Run the command using subprocess
#                 try:
#                     subprocess.check_call(command)
#                     iface.messageBar().pushMessage("QGINLA:",'dependencies installed successfully!',Qgis.Success)
#                     #MessageHandler.success('QGINLA: dependencies installed successfully!')
#                 except subprocess.CalledProcessError:
#                     iface.messageBar().pushMessage("QGINLA:",'error occurred while installing dependencies. Please try to install them manually using pip',Qgis.Critical)
#                     sys.exit('error occurred while installing dependencies. Please try to install them manually using pip')
#                     #MessageHandler.error('QGINLA: error occurred while installing dependencies. Please try to install them manually using pip')



def loadenv():
    # Define the path to your .env file
    dir=os.path.dirname(os.path.abspath(__file__))
    env_file_path = dir+'/.env'

    # Check if the .env file exists
    if os.path.exists(env_file_path):
        # Open and read the .env file
        with open(env_file_path, 'r') as file:
            lines = file.readlines()

        # Parse each line and set environment variables
        for line in lines:
            line = line.strip()  # Remove leading/trailing whitespace and newline characters
            if line and not line.startswith('#'):  # Ignore empty lines and comments
                key, value = line.split('=', 1)
                os.environ[key] = value
