from qgis.core import (QgsVectorLayer,
                       QgsFields,
                       QgsField,
                       QgsProject,
                       QgsVectorFileWriter,
                       QgsWkbTypes,
                       QgsFeature,
                       QgsGeometry,
                       QgsProcessingContext,
)
import numpy as np
import pandas as pd
from qgis.PyQt.QtCore import QVariant
import os
from shapely.geometry import shape
from shapely.wkt import dumps
import fiona
from qgis.PyQt.QtCore import *
from qgis.utils import iface
import os
import os.path as op
from qgis.core import QgsVectorLayer
from ctypes import cdll
import fiona
from shapely.wkt import dumps
from shapely.geometry import shape


class gui_utils:
    
    @staticmethod  
    def load_geopackage(file_path, table_name='file'):
        print('loading dataframe')
        layer = QgsVectorLayer(file_path, 'Input Layer', 'ogr')
        crs=layer.crs()
        input_gpkg = file_path
        with fiona.open(input_gpkg) as source:
            records = []
            for feature in source:
                properties = feature['properties']
                geom_wkt = dumps(shape(feature['geometry']))
                properties['geom'] = geom_wkt  
                records.append(properties)
        df = pd.DataFrame(records)
        del layer
        del source
        del records
        return df,crs
    
    @staticmethod 
    def generate_ghost_input(input,output):
        input_shapefile_path = input
        layer = QgsVectorLayer(input_shapefile_path, 'Input Layer', 'ogr')
        transform_context = QgsProject.instance().transformContext()
        save_options = QgsVectorFileWriter.SaveVectorOptions()
        save_options.driverName = 'GPKG'
        save_options.fileEncoding = 'UTF-8'
        writer = QgsVectorFileWriter.writeAsVectorFormat(
          layer,  
          output,
          save_options
        )
        print(output)
        del writer
        del layer

    @staticmethod
    def load_vector_to_canvas(directory,filename):
        """Load layer in map canvas"""

        output_layer = QgsVectorLayer(op.join(directory,filename)+'.gpkg', filename,"ogr")
        QgsProject.instance().addMapLayer(output_layer, True)

    #def graph_ID_generator(df) -> pd.DataFrame:
    #    df.insert(0, 'ID_unstruc', range(0, len(df)))
    #    return(df)

    def df_to_gpkg(df,y,directory,filename,crs):
        print('writing output geopackage.....')
        nomi=list(df.head())
        fields = QgsFields()

        for field in nomi:
            #if field=='ID_code':
            #    fields.append(QgsField(field, QVariant.Int))
            if field=='geom':
                continue
            if field==y:
                fields.append(QgsField(field, QVariant.Double))
            else:
                fields.append(QgsField(field, QVariant.Double))
        transform_context = QgsProject.instance().transformContext()
        save_options = QgsVectorFileWriter.SaveVectorOptions()
        save_options.driverName = 'GPKG'
        save_options.fileEncoding = 'UTF-8'
        writer = QgsVectorFileWriter.create(
          op.join(directory,filename),
          fields,
          QgsWkbTypes.Polygon,
          crs,
          transform_context,
          save_options
        )
        if writer.hasError() != QgsVectorFileWriter.NoError:
            print("Error when creating shapefile: ",  writer.errorMessage())
        for i, row in df.iterrows():
            fet = QgsFeature()
            fet.setGeometry(QgsGeometry.fromWkt(row['geom']))
            fet.setAttributes(list(map(float,list(df.loc[ i, df.columns != 'geom']))))
            writer.addFeature(fet)
        del writer