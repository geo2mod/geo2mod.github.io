# -*- coding: utf-8 -*-
"""
/***************************************************************************
 QGINLA
                                 A QGIS plugin
 INLA for QGIS
                             -------------------
        begin                : 2023-07-01
        copyright            : (C) 2023 by giacomo titti
        email                : giacomo.titti@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""


