# -*- coding: utf-8 -*-
"""
/***************************************************************************
 QGINLA
                                 A QGIS plugin
 INLA for QGIS
                             -------------------
        begin                : 2023-07-01
        copyright            : (C) 2023 by giacomo titti
        email                : giacomo.titti@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 3 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""


import os
import os.path as op

from osgeo import gdal
from PyQt5.QtCore import Qt
from qgis.core import QgsProviderRegistry, QgsMapLayerProxyModel, QgsVectorLayer, QgsProject
from qgis.PyQt.QtCore import QCoreApplication
from qgis.utils import iface
from qgis.PyQt.uic import loadUi
from qgis.PyQt.QtWidgets import QComboBox, QDialog, QFileDialog, QDialogButtonBox, QMessageBox,\
    QCheckBox,QHeaderView, QDoubleSpinBox
import tempfile
from pyinla.inla_main import inla_class
from interfaces.utils import gui_utils


class TheWidget(QDialog):
    """ QDialog to interactively set up the QGINLA input and output. """

    def __init__(self):
        super(TheWidget, self).__init__()
        loadUi(op.join(op.dirname(__file__), 'gui.ui'), self)

        # set input vector
        self.vectorDropDown.setCurrentIndex(-1)
        self.vectorDropDown.setFilters(QgsMapLayerProxyModel.VectorLayer)
        self.vectorDropDown.layerChanged.connect(self._choose_vector)
        self.imageAction.triggered.connect(self._browse_for_vector)
        self.vectorButton.setDefaultAction(self.imageAction)

        # set dependent variable
        self.yFieldComboBox.setEnabled(False)
        self.vectorDropDown.layerChanged.connect(self.yFieldComboBox.setLayer)
        self.yFieldComboBox.fieldChanged.connect(self._choose_y_field)

        # set independet variables table
        self.field_table_widget.setEnabled(False) 
        self.field_table_widget.setColumnCount(6)
        self.field_table_widget.setHorizontalHeaderLabels(['Field name','Effects','Type', 'Prior','Hyp (a)','Hyp (b)'])
        self.field_table_widget.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeToContents)
        self.field_table_widget.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.field_table_widget.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.field_table_widget.horizontalHeader().setSectionResizeMode(3, QHeaderView.Stretch)
        self.field_table_widget.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
        self.field_table_widget.horizontalHeader().setSectionResizeMode(5, QHeaderView.Stretch)
        self.field_table_widget.horizontalHeader().setMinimumSectionSize(120)
        self.field_table_widget.verticalHeader().setDefaultSectionSize(40)
        self.vectorDropDown.layerChanged.connect(self.populate_layer_combo_box)

        # set latent effect
        self.smooth_checkBox.setEnabled(False)
        self.frame_smooth.setEnabled(False)
        self.smooth_checkBox.stateChanged.connect(lambda state: self.smooth_checkbox_state_changed(state))
        self.IDmFieldComboBox.setCurrentIndex(-1)
        self.vectorDropDown.layerChanged.connect(self.IDmFieldComboBox.setLayer)
        #self.IDmFieldComboBox.fieldChanged.connect(self.smoothing_choose_ID_field)
        self.bym_comboBox.addItems(['bym','bym2','besag','iid'])
        self.bym_comboBox.setCurrentIndex(-1)
        #self.prior_comboBox.addItems(['loggamma','pc.prec'])
        self.prior_comboBox.setCurrentIndex(-1)
        self.prior_comboBox.setEnabled(False)
        self.hyp1.setEnabled(False)
        self.hyp2.setEnabled(False)
        self.hyp3.setEnabled(False)
        self.hyp4.setEnabled(False)
        self.bym_comboBox.currentTextChanged.connect(lambda index, row=0, column=0: self.update_combobox_smoothing_type(row, column, index))
        self.prior_comboBox.currentTextChanged.connect(lambda index, row=0, column=0: self.update_combobox_smoothing_prior(row, column, index)) 
        self.hyp1.setDecimals(3)    
        self.hyp2.setDecimals(3)  
        self.hyp3.setDecimals(3)  
        self.hyp4.setDecimals(3)       
        self.hyp1.setSingleStep(0.001)
        self.hyp2.setSingleStep(0.001)
        self.hyp3.setSingleStep(0.001)
        self.hyp4.setSingleStep(0.001)
        self.hyp1.valueChanged.connect(self.on_spin_box_value_changed_latent)
        self.hyp2.valueChanged.connect(self.on_spin_box_value_changed_latent)
        self.hyp3.valueChanged.connect(self.on_spin_box_value_changed_latent)
        self.hyp4.valueChanged.connect(self.on_spin_box_value_changed_latent)

        #set scale method
        self.scaleComboBox.setEnabled(False)
        self.scaleComboBox.addItem('zero',"center scale over zero")
        self.scaleComboBox.addItem('minmax',"scale between min and max")
        self.scaleComboBox.setCurrentIndex(-1)
        self.scaleComboBox.currentTextChanged.connect(self._choose_scale_method)

        #family
        self.familyComboBox.setEnabled(False)
        self.familyComboBox.addItem('gaussian',"gaussian")
        self.familyComboBox.addItem('poisson',"poisson")
        self.familyComboBox.addItem('binomial',"binomial")
        self.familyComboBox.setCurrentIndex(-1)
        self.familyComboBox.currentTextChanged.connect(self._choose_family)
        self.offFieldComboBox.setEnabled(False)
        self.label_12.setEnabled(False)
        self.vectorDropDown.layerChanged.connect(self.offFieldComboBox.setLayer)
        self.offFieldComboBox.fieldChanged.connect(self._choose_off_field)


        # output folder
        self.outputlineEdit.setReadOnly(True)
        self.outputlineEdit.setPlaceholderText('[Create temporary folder]')
        #self.outputFileWidget.setStorageMode(QgsFileWidget.SaveFile)
        #elf.outputFileWidget.setFilter("Shp (*.shp);;All (*.*)")
        self.outputpushButton.clicked.connect(self._selectFolder)

        # Open in QGIS?
        try:
            iface.activeLayer
        except AttributeError:
            self.openCheckBox.setChecked(False)
            self.openCheckBox.setDisabled(True)

        # run or cancel
        self.OKClose.button(QDialogButtonBox.Ok).setText("Run")
        self.OKClose.accepted.connect(self._run)
        self.OKClose.rejected.connect(self.close)

        # widget variables
        self.image = None
        self.classified = None

    def log(self, text):
        # append text to log window
        self.logBrowser.append(str(text) + '\n')
        # open the widget on the log screen
        self.tabWidget.setCurrentIndex(self.tabWidget.indexOf(self.tab_log))

    def _browse_for_vector(self):
        """ Browse for a vector file """

        path = QFileDialog.getOpenFileName(filter=QgsProviderRegistry.instance().fileVectorFilters())[0]
        try:
            if len(path) > 0:
                gdal.UseExceptions()
                layer = QgsVectorLayer(path, os.path.splitext(op.basename(path))[0], 'ogr')
                assert layer.isValid()
                QgsProject.instance().addMapLayer(layer, True)

                self.vectorDropDown.setLayer(layer)
        except AssertionError:
            self.log("'" + path + "' not recognized as a supported file format.")
        except Exception as e:
            self.log(e)

    def _choose_vector(self):
        """ Choose vector file """

        self.cleanup_gui()
        layer = self.vectorDropDown.currentLayer()
        if layer is None:
            return
        try:
            print('loaded')
        except Exception as e:
            self.log(e)
        
    def _choose_y_field(self):
        """Action on click dependent variable"""

        self.y_field = self.yFieldComboBox.currentField()  
    
    def _choose_off_field(self):
        """Action on click offset for family"""

        self.off_field = self.offFieldComboBox.currentField()  

    def _choose_scale_method(self):
        """Action on click scale method"""

        self.scale_method = self.scaleComboBox.itemText(self.scaleComboBox.currentIndex())
    
    def _choose_family(self):
        """Action on click family"""

        self.offFieldComboBox.setCurrentIndex(-1)
        self.family = self.familyComboBox.itemText(self.familyComboBox.currentIndex())
        if self.family=='poisson':
            self.offFieldComboBox.setEnabled(True)
            self.label_12.setEnabled(True)
        else:
            self.offFieldComboBox.setEnabled(False)
            self.label_12.setEnabled(False)
            self.off_field = ''

    def _selectFolder(self):
        options = QFileDialog.Options()
        self.outputlineEdit.setText(QFileDialog.getExistingDirectory(self, 'Select Folder', options=options))
    
    def smooth_checkbox_state_changed(self, state):
        if state == Qt.Checked:
            self.graph=True
            self.frame_smooth.setEnabled(True)
            self.update_combobox_smoothing_type(row=0 , column= 0, index=0)
        else:
            self.graph=False
            self.frame_smooth.setEnabled(False)
            self.remove_parms(level='smooth', key='smooth', row=0)

    def field_checkbox_state_changed(self, state, item):
        """Action on state change """

        if state == Qt.Checked:
            widget = self.field_table_widget.cellWidget(item, 1)
            widget.setEnabled(True)
            self.update_combobox(item, 1, widget.currentText())
        else:
            widget = self.field_table_widget.cellWidget(item, 1)
            widget.setEnabled(False)           
            self.field_table_widget.cellWidget(item, 2).setEnabled(False)
            self.field_table_widget.cellWidget(item, 3).setEnabled(False)
            self.field_table_widget.cellWidget(item, 4).setEnabled(False)
            self.field_table_widget.cellWidget(item, 5).setEnabled(False)
            self.remove_parms(level='field', key=self.field_table_widget.cellWidget(item, 0).text(), row=item)

    def update_combobox(self, row, column, index):
        """Update combobox effects"""

        self.add_parms(level='field', key=self.field_table_widget.cellWidget(row, 0).text(), row=row)
        effect=self.field_table_widget.cellWidget(row, 1).currentText()
        type=self.field_table_widget.cellWidget(row, 2).currentText()
        if (effect == 'random' and type =='iid') or (effect == 'random' and type =='rw1'):
            self.field_table_widget.cellWidget(row, 2).setEnabled(True)
            self.field_table_widget.cellWidget(row, 3).setEnabled(True)
            self.field_table_widget.cellWidget(row, 4).setEnabled(True)
            self.field_table_widget.cellWidget(row, 5).setEnabled(True)
        elif effect== 'fixed':
            self.field_table_widget.cellWidget(row, 2).setEnabled(False)
            self.field_table_widget.cellWidget(row, 3).setEnabled(False)
            self.field_table_widget.cellWidget(row, 4).setEnabled(False)
            self.field_table_widget.cellWidget(row, 5).setEnabled(False)

    def update_combobox_prior(self, row, column, index):
        prior=self.field_table_widget.cellWidget(row, 3).currentText()
        if prior == 'loggamma':
            self.field_table_widget.cellWidget(row, 4).setValue(1.000)
            self.field_table_widget.cellWidget(row, 5).setValue(0.001)
        elif prior == 'pc.prec':
            self.field_table_widget.cellWidget(row, 4).setValue(1.000)
            self.field_table_widget.cellWidget(row, 5).setValue(0.010)
    
    def update_combobox_smoothing_type(self, row, column, index):
        type=self.bym_comboBox.currentText()
        if type=='besag' or type=='bym':
            self.prior_comboBox.clear()
            self.prior_comboBox.setEnabled(False)
            self.prior_comboBox.addItems(['loggamma'])
        elif type=='bym2':
            self.prior_comboBox.clear()
            self.prior_comboBox.setEnabled(False)
            self.prior_comboBox.addItems(['pc.prec'])
        elif type=='iid':
            self.prior_comboBox.clear()
            self.prior_comboBox.setEnabled(True)
            self.prior_comboBox.addItems(['loggamma','pc.prec'])

    def update_combobox_smoothing_prior(self, row, column, index):
        """Update combobox latent effect"""

        self.add_parms(level='smooth', key='smooth', row=row)
        type=self.bym_comboBox.currentText()
        if type=='bym' or type=='bym2':
            self.hyp1.setEnabled(True)
            self.hyp2.setEnabled(True)
            self.hyp3.setEnabled(True)
            self.hyp4.setEnabled(True)
        elif type=='besag' or type=='iid':
            self.hyp1.setEnabled(True)
            self.hyp2.setEnabled(True)
            self.hyp3.setEnabled(False)
            self.hyp4.setEnabled(False)
        
    
        prior=self.prior_comboBox.currentText()
        if type=='besag':
            if prior == 'loggamma':
                self.hyp1.setValue(4.000)
                self.hyp2.setValue(0.005)
        elif type=='bym':
            if prior == 'loggamma':
                self.hyp1.setValue(1.000)
                self.hyp2.setValue(0.005)
                self.hyp3.setValue(1.000)
                self.hyp4.setValue(0.001)
        elif type=='bym2':
            if prior == 'pc.prec':
                self.hyp1.setValue(1.613)
                self.hyp2.setValue(0.010)
                self.hyp3.setValue(0.500)
                self.hyp4.setValue(0.500)
        elif type=='iid':
            if prior == 'loggamma':
                self.hyp1.setValue(1.000)
                self.hyp2.setValue(0.001)
            elif prior == 'pc.prec':
                self.hyp1.setValue(1.000)
                self.hyp2.setValue(0.010)

    def on_spin_box_value_changed(self,value):
        """Action on click Spin box Hyp"""
        row = self.field_table_widget.currentRow()
        self.add_parms(level='field', key=self.field_table_widget.cellWidget(row, 0).text(), row=row)

    def on_spin_box_value_changed_latent(self,value):
        """Action on click Spin box Hyp latent"""
        self.add_parms(level='smooth', key='smooth', row=0)

    def populate_layer_combo_box(self):
        """Populate list of input vectors"""

        self.field_table_widget.setEnabled(True) 
        self.smooth_checkBox.setEnabled(True)
        self.scaleComboBox.setEnabled(True)
        self.familyComboBox.setEnabled(True)
        self.yFieldComboBox.setEnabled(True)

        # Get a list of vector layers from the QGIS project
        self.field_table_widget.clearContents()
        rows_to_delete=list(range(0, self.field_table_widget.rowCount()))
        for row_index in sorted(rows_to_delete, reverse=True):
            self.field_table_widget.removeRow(row_index)

        layer = self.vectorDropDown.currentLayer()

        if layer is None:
            self.log('Layer selected is not valid')
            return

        fields = layer.fields()

        self.parms={}

        #Add the vector layer names to the combo box
        for field in fields:
            row = self.field_table_widget.rowCount()
            self.field_table_widget.insertRow(row)

            widget_first_col = QCheckBox()
            widget_first_col.setText(field.name())
            widget_first_col.setChecked(False)
            widget_first_col.setStyleSheet("QCheckBox { padding-left: 6px; margin: 7px;}")
            
            # Add the field name, checkbox, and type to the table
            self.field_table_widget.setCellWidget(row, 0, widget_first_col)
            widget_first_col.stateChanged.connect(lambda state, row=row: self.field_checkbox_state_changed(state, row))

            col=1
            # Create the combobox and add the options
            self.combobox_first_col = QComboBox()
            self.combobox_first_col.setStyleSheet("QComboBox { padding-left: 6px; margin: 7px;}")
            self.combobox_first_col.addItems(['fixed','random'])
            self.combobox_first_col.currentTextChanged.connect(lambda index, row=row, column=1: self.update_combobox(row, column, index))         
            self.combobox_first_col.setEnabled(False)

            # Add the field name, checkbox, and type to the table
            self.field_table_widget.setCellWidget(row, col, self.combobox_first_col)
            
            # Create the combobox and add the options
            self.combobox_third_col = QComboBox()
            self.combobox_third_col.setStyleSheet("QComboBox { padding-left: 6px; margin: 7px;}")
            self.combobox_third_col.addItems(['iid','rw1'])
            self.combobox_third_col.currentTextChanged.connect(lambda index, row=row, column=2: self.update_combobox(row, column, index))
            self.combobox_third_col.setEnabled(False)
            self.field_table_widget.setCellWidget(row, col+1, self.combobox_third_col)

            # Create the combobox and add the options
            self.combobox_fourth_col = QComboBox()
            self.combobox_fourth_col.setStyleSheet("QComboBox { padding-left: 6px; margin: 7px;}")
            self.combobox_fourth_col.addItems(['loggamma','pc.prec'])
            self.combobox_fourth_col.currentTextChanged.connect(lambda index, row=row, column=3: self.update_combobox_prior(row, column, index))
            self.combobox_fourth_col.setEnabled(False)
            self.field_table_widget.setCellWidget(row, col+2, self.combobox_fourth_col)

            # Create the spinbox
            self.dspinbox_fifth_col = QDoubleSpinBox()
            self.dspinbox_fifth_col.setStyleSheet("QDoubleSpinBox { padding-left: 6px; margin: 6px;}")
            self.dspinbox_fifth_col.setDecimals(3)
            self.dspinbox_fifth_col.setRange(0.0, 100.0)
            self.dspinbox_fifth_col.setSingleStep(0.001)
            self.dspinbox_fifth_col.setValue(1.0)  # Default value is 2.0
            self.dspinbox_fifth_col.valueChanged.connect(self.on_spin_box_value_changed)
            self.dspinbox_fifth_col.setEnabled(False)
            self.field_table_widget.setCellWidget(row, col+3, self.dspinbox_fifth_col)

            # Create the spinbox
            self.dspinbox_sixth_col = QDoubleSpinBox()
            self.dspinbox_sixth_col.setStyleSheet("QDoubleSpinBox {padding-left: 6px; margin: 6px;}")
            self.dspinbox_sixth_col.setDecimals(3)
            self.dspinbox_sixth_col.setRange(0.00, 100.00)
            self.dspinbox_sixth_col.setSingleStep(0.001)
            self.dspinbox_sixth_col.setValue(0.001)  # Default value is 2.0
            self.dspinbox_sixth_col.valueChanged.connect(self.on_spin_box_value_changed)
            self.dspinbox_sixth_col.setEnabled(False)
            self.field_table_widget.setCellWidget(row, col+4, self.dspinbox_sixth_col)
    
    def add_parms(self, level, key, row):
        """Store the parameters selected in the GUI"""

        if level=='field': 
            effect=self.field_table_widget.cellWidget(row, 1).currentText()
            type=self.field_table_widget.cellWidget(row, 2).currentText()            
            if effect=='random':
                if type=='iid' or type=='rw1':
                    self.parms[key]={
                        'effect':self.field_table_widget.cellWidget(row, 1).currentText(),
                        'type':self.field_table_widget.cellWidget(row, 2).currentText(),
                        'prior':self.field_table_widget.cellWidget(row, 3).currentText(),
                        'hypa':self.field_table_widget.cellWidget(row, 4).value(),
                        'hypb':self.field_table_widget.cellWidget(row, 5).value()
                    }
                    
            elif effect=='fixed':
                try:
                    del self.parms[key]
                    self.parms[key]={'effect':'fixed',
                    }
                except:
                    self.parms[key]={'effect':'fixed',
                    }
        elif level=='smooth':
            smooth=self.bym_comboBox.currentText()
            if smooth=='besag':
                self.parms[key]={
                    'ID':self.IDmFieldComboBox.currentField(),
                    'type':'besag',
                    'prior':'loggamma',
                    'hyp1':self.hyp1.value(),
                    'hyp2':self.hyp2.value()
                }
            elif smooth=='iid':
                self.parms[key]={
                    'ID':self.IDmFieldComboBox.currentField(),
                    'type':'Siid',
                    'prior':self.prior_comboBox().currentText(),
                    'hyp1':self.hyp1.value(),
                    'hyp2':self.hyp2.value()
                }
            elif smooth=='bym':
                self.parms[key]={
                    'ID':self.IDmFieldComboBox.currentField(),
                    'type':'bym',
                    'prior':'loggamma',
                    'hyp1':self.hyp1.value(),
                    'hyp2':self.hyp2.value(),
                    'hyp3':self.hyp3.value(),
                    'hyp4':self.hyp4.value()
                }
            elif smooth=='bym2':
                self.parms[key]={
                    'ID':self.IDmFieldComboBox.currentField(),
                    'type':'bym2',
                    'prior':'pc.prec',
                    'hyp1':self.hyp1.value(),
                    'hyp2':self.hyp2.value(),
                    'hyp3':self.hyp3.value(),
                    'hyp4':self.hyp4.value()
                }       
        
        if os.getenv('DEBUG')=='True':
            print(self.parms)

    def remove_parms(self, level, key, row):
        """Action if deselect parameters"""

        if level=='field': 
            del self.parms[key]
        elif level=='smooth':
            try:
                del self.parms[key]
            except:
                pass
        if os.getenv('DEBUG')=='True':
            print(self.parms)
    
    def cleanup_gui(self):
        """"Cleanup GUI when change vector input"""

        self.field_table_widget.clearContents()
        rows_to_delete=list(range(0, self.field_table_widget.rowCount()))
        for row_index in sorted(rows_to_delete, reverse=True):
            self.field_table_widget.removeRow(row_index)
        self.scaleComboBox.setCurrentIndex(-1)
        self.familyComboBox.setCurrentIndex(-1)
        self.smooth_checkBox.setChecked(False)
        self.frame_smooth.setEnabled(False)
        self.bym_comboBox.setCurrentIndex(-1)

        
    def _run(self):
        """ Read all parameters and pass them on to the core function"""

        if not self.vectorDropDown.currentLayer():
            message = QCoreApplication.translate('Message to user','Please select input vector') 
            QMessageBox.warning(None, QCoreApplication.translate('Message to user', 'Missing Information'), message)
            return False
        elif len(self.yFieldComboBox.currentField())==0:
            message = QCoreApplication.translate('Message to user','Please select dependent variable') 
            QMessageBox.warning(None, QCoreApplication.translate('Message to user', 'Missing Information'), message)
            return False
        elif len(self.parms.keys())==0:
            message = QCoreApplication.translate('Message to user','Please select at least one covariate') 
            QMessageBox.warning(None, QCoreApplication.translate('Message to user', 'Missing Information'), message)
            return False
        # elif len(self.scaleComboBox.itemText(self.scaleComboBox.currentIndex()))==0:
        #     message = QCoreApplication.translate('Message to user','Please select at least one scale method') 
        #     QMessageBox.warning(None, QCoreApplication.translate('Message to user', 'Missing Information'), message)
        #     return False
        elif len(self.familyComboBox.itemText(self.familyComboBox.currentIndex()))==0:
            message = QCoreApplication.translate('Message to user','Please select at least one family') 
            QMessageBox.warning(None, QCoreApplication.translate('Message to user', 'Missing Information'), message)
            return False
        elif self.familyComboBox.itemText(self.familyComboBox.currentIndex())=='poisson' and len(self.offFieldComboBox.currentField())==0:
            message = QCoreApplication.translate('Message to user','Please select an offset for poisson family') 
            QMessageBox.warning(None, QCoreApplication.translate('Message to user', 'Missing Information'), message)
            return False
        else:
            output_path = self.outputlineEdit.text()
            f=tempfile.gettempdir()

            # Get parameters
            vector_path = self.vectorDropDown.currentLayer().source()
            #gdf, vlayer, metadata = utils.import_vector(vector_path)
            gui_utils.generate_ghost_input(vector_path,f+'/file.gpkg')
            df,crs=gui_utils.load_geopackage(f+'/file.gpkg', table_name='file')

            if len(output_path) == 0:
                output_path = tempfile.mkdtemp()
            self.log('outputs saved to: '+output_path)
            
            try:
                self.scale_method
            except:
                self.scale_method=None

            # run code
            [INLA,df_fittedvalues,df_linearpredictor,df_latenteffect]=inla_class(df).execute(vector_path=vector_path, y_field=self.y_field ,cov_fields=self.parms, scale_method=self.scale_method, family=self.family, offset=self.off_field, directory=output_path, set_progress=self.progressBar.setValue, log=self.log)


            if df_fittedvalues is not None:
                gui_utils.df_to_gpkg(df_fittedvalues,self.y_field,output_path,'fittedvalues',crs)
                if self.openCheckBox.isChecked():    
                    gui_utils.load_vector_to_canvas(output_path,'fittedvalues')

            if df_linearpredictor is not None:
                gui_utils.df_to_gpkg(df_linearpredictor,self.y_field,output_path,'linearpredictor',crs)
                if self.openCheckBox.isChecked():
                    gui_utils.load_vector_to_canvas(output_path,'linearpredictor')

            if df_latenteffect is not None:
                gui_utils.df_to_gpkg(df_latenteffect,self.y_field,output_path,'latenteffect',crs)
                if self.openCheckBox.isChecked():
                    gui_utils.load_vector_to_canvas(output_path,'latenteffect')

        self.progressBar.setValue(100)
