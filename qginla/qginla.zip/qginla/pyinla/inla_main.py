
import numpy as np
import os.path as op
import pandas as pd
import rpy2.robjects as robjects
from rpy2.robjects import pandas2ri
from rpy2.robjects.packages import SignatureTranslatedAnonymousPackage
from sklearn.preprocessing import scale
from pyinla.utils import pyinla_utils
#import matplotlib.pyplot as plt




class inla_class():

    def __init__(self, gdf):

        #self.pathFormula=op.join(op.dirname(__file__), 'formula.R')

        self.gdf=gdf

        #ID gen
        gdf,self.ID_column = pyinla_utils.ID_generator(gdf)

        # variables required for using the algorithm inside a UI
        self.set_progress = None
        self.print_log = None
    
    def execute(self,vector_path,y_field, cov_fields, scale_method,family, offset, directory, set_progress: callable = None,log: callable = print):
        """Execute the run"""


        self.set_progress = set_progress if set_progress else inla_class.printProgress
        self.print_log = log if log else print

        self.print_log('Start analysis')
        self.set_progress(0)

        myformula = {'response': 'y'}
       
        myformula['intercept'] = 1

        try:
            columns=list(cov_fields.keys())
            columns.remove('smooth')
        except:
            columns=list(cov_fields.keys())
                
        #scale the values
        columns_to_scale=columns
        gdf_scaled=pyinla_utils.to_scale(self.gdf,columns_to_scale,scale_method)
        self.print_log('Covariate scaled')
        self.set_progress(10)


        #remove rows with NaN 
        columns_to_check=columns
        columns.append(self.ID_column)
        ################################ask to Anna
        #gdf_scaled_dropna=utils.to_drop_nan(gdf_scaled,columns_to_check)
        #self.print_log('Null values deleted')
        ################################ask to Anna

        self.set_progress(20)

        #build graph object
        g_path=pyinla_utils.graph_calculator(vector_path,self.ID_column)#cambiare con ID
        
        self.set_progress(30)

        # convert the GeoDataFrame to a Pandas DataFrame
        #df = gdf_scaled.drop("geometry", axis=1)
        #df=gdf_scaled.copy()

        #select columns (covariates) from input vector
        columns_selected=columns+[y_field]
        #elf.df = df[columns_selected]

        #list of covariates
        fixed_var=[]
        for key,value in cov_fields.items():
            if pyinla_utils.find_key(cov_fields[key], 'fixed'):
                fixed_var.append(key)
        if len(fixed_var)>0:
            myformula['fixed']=fixed_var

        myformula['random']={}
        for key,value in cov_fields.items():
            if pyinla_utils.find_key(cov_fields[key], 'random'):
                random_eff=pyinla_utils.type_constructor(key,cov_fields[key]['type'],prior=cov_fields[key]['prior'],hyp1=cov_fields[key]['hypa'],hyp2=cov_fields[key]['hypb'],graph=g_path)
                myformula['random'][key] = random_eff

        if 'smooth' in list(cov_fields):
            key='smooth'
            try:
                random_eff=pyinla_utils.type_constructor(key,cov_fields[key]['type'],prior=cov_fields[key]['prior'],hyp1=cov_fields[key]['hyp1'],hyp2=cov_fields[key]['hyp2'],graph=g_path,ID=cov_fields[key]['ID'],hyp3=cov_fields[key]['hyp3'],hyp4=cov_fields[key]['hyp4'])#sistemare prior
            except:
                random_eff=pyinla_utils.type_constructor(key,cov_fields[key]['type'],prior=cov_fields[key]['prior'],hyp1=cov_fields[key]['hyp1'],hyp2=cov_fields[key]['hyp2'],graph=g_path,ID=cov_fields[key]['ID'])#sistemare prior
            myformula['random'][key] = random_eff
            

        try:
            columns_name=columns+[y_field]+[cov_fields[key]['ID']]
        except:
            columns_name=columns+[y_field]

        self.set_progress(50)

        inference=pyinla_utils.inla_call(gdf_scaled[columns_name],family,myformula,np.ones(len(gdf_scaled)))

        if 'summary.fixed' in inference:
            summary_fixed_df = inference['summary.fixed']
            summary_fixed_df.to_csv(directory+'/summary_fixed.csv', index=True) 
            #df_fixedvalues = pyinla_utils.merge_dataframes(self.ID_column,summary_fixed_df,gdf_scaled)
        else:
            df_fixedvalues = None

        if 'summary.random' in inference:
            summary_random_df = inference['summary.random']
            count=0
            for key in summary_random_df.keys():
                var=summary_random_df[key]
                if 'smooth' in list(cov_fields):
                    item='smooth'
                    if cov_fields[item]['type']=='bym' or cov_fields[item]['type']=='bym2':
                        df_latenteffect_half1 = pyinla_utils.merge_dataframes(self.ID_column,var.iloc[0:int(len(var)/2)],gdf_scaled)
                        df_latenteffect_half2 = pyinla_utils.merge_dataframes(self.ID_column,var.iloc[int(len(var)/2):int(len(var))],gdf_scaled)
                        df_latenteffect=[df_latenteffect_half1,df_latenteffect_half2]
                    else:
                        df_latenteffect = [pyinla_utils.merge_dataframes(self.ID_column,var,gdf_scaled)]    
                    df_latenteffect.to_csv(directory+'/latenteffect'+key+'.csv', index=True)   
                else:
                    df_latenteffect=None                 
                count+=1   
                summary_random_df[key].to_csv(directory+'/summary_random_'+key+'.csv', index=True) 
 
        else:
            df_latenteffect=None
            summary_random_df=None

        if 'summary.linear.predictor' in inference:
            summary_linear_predictor_df = inference['summary.linear.predictor']
            summary_linear_predictor_df.to_csv(directory+'/summary_linear_predictor.csv', index=True) 
            df_linearpredictor = pyinla_utils.merge_dataframes(self.ID_column,summary_linear_predictor_df,gdf_scaled)
        else:
            df_linearpredictor = None
        
        if 'summary.fitted.values' in inference:
            summary_fitted_values_df = inference['summary.fitted.values']
            summary_fitted_values_df.to_csv(directory+'/summary_fitted_values.csv', index=True) 
            df_fittedvalues = pyinla_utils.merge_dataframes(self.ID_column,summary_fitted_values_df,gdf_scaled)
        else:
            df_fittedvalues=None

        self.print_log('INLA ended')
        self.set_progress(90)
       
        self.print_log('End analysis')
    
        #prepare output layers
        #convert pandas dataframe into geopandas dataframe


        #choose the plot according to the formula
        # if len(summary_fixed_df)!=0:
        #     self.plotfixed(summary_fixed_df,cov_fields)
        # if len(summary_random_df)!=0:
        #     self.plotrandom(summary_random_df,cov_fields)

        return([inference, df_fittedvalues,df_linearpredictor,df_latenteffect])
        #return([inference,summary_fixed_df,summary_random_df,df_fittedvalues,df_linearpredictor,df_latenteffect])

    def printProgress(value: int):
        """ Replacement for the GUI progress bar """
        print('progress: {} %'.format(value))
