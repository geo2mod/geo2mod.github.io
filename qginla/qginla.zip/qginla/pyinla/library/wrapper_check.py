import subprocess
import sys

def check_r_installed():
    try:
        subprocess.run(["R", "--version"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print("R is installed.")
    except subprocess.CalledProcessError:
        print("R is not installed.")

def check_r_library(library_name):
    try:
        subprocess.run(["R", "--slave", "-e", f"library({library_name})"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print(f"R library '{library_name}' is installed.")
    except subprocess.CalledProcessError:
        print(f"R library '{library_name}' is not installed.")

def check_rpy2_installed():
    try:
        import rpy2
        print("rpy2 is installed.")
    except ImportError:
        print("rpy2 is not installed.")

def main_check():
    check_r_installed()
    check_rpy2_installed()
    # Check for R libraries
    check_r_library('INLA')
    check_r_library('Matrix')



def validate_distribution(y, likelihood):
    if likelihood == "poisson":
        # Check if non-missing values are integers and >= 0
        if all(y.dropna().apply(lambda x: x >= 0 and x == int(x))):
            return True
        else:
            return False

    elif likelihood == "binomial":
        # Check if non-missing values are non-negative integers
        if all(y.dropna().apply(lambda x: x >= 0 and x == int(x))):
            return True
        else:
            return False

    elif likelihood == "gaussian":
        # Gaussian can include any real numbers
        return True

    else:
        return "Likelihood is not yet implemented, please contact esmail.abdulfattah@kaust.edu.sa"


def standardize_series(series):
    return (series - series.mean()) / series.std()


def validate_and_correct_parameters(effect_dict, default_a=1, default_b=0.001):
    if False:
        if effect_dict.get('model') == 'iid':  # Check if the model is 'iid'
            a, b = effect_dict['hyper']['prec']['param']
            if not (0 < a <= 1) or not (0 < b <= 1):  # Validate the range
                # Set default values if conditions are not met
                effect_dict['hyper']['prec']['param'] = [default_a, default_b]
                return True  # Return True after setting to defaults
        elif effect_dict.get('model') == 'rw1':  # Check if the model is 'iid'
            a, b = effect_dict['hyper']['prec']['param']
            if not (0 < a <= 1) or not (0 < b <= 1):  # Validate the range
                # Set default values if conditions are not met
                effect_dict['hyper']['prec']['param'] = [default_a, default_b]
                return True  # Return True after setting to defaults
        return True  # Return True if the model is not 'iid' or parameters are already valid
