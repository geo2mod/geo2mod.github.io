# -------------------------------------------------------------------
# File: inla.py
# Author: Esmail Abdul Fattah
# Email: esmail@r-inla.org
# 
# Copyright (c) 2024 [Esmail Abdul Fattah]. All rights reserved.
# 
# This code is intended solely for use in the QGINLA project. 
# Unauthorized copying, editing, or distribution of this file, 
# via any medium, is strictly prohibited without prior written
# permission from the author.
# -------------------------------------------------------------------

from qginla.pyinla.library.py_inla_formula import *


##-----------------------------------------------------------------------------------------------------------------------------------------------------------
##                                                             Main Functions                                                             
##-----------------------------------------------------------------------------------------------------------------------------------------------------------
    

def summary(res, tit_user = None):

    inla_data = processing(res)    
    title = "      Summary of the model"
    print(title)
    print("    <-><-><-><-><-><-><-><->" )
    print('\n')
    s = "     Time used:"
    print(s)
    print("     ----------")
    cpu_data = inla_data['cpu.used']
    pre_value = cpu_data.at[0, 'Pre']
    running_value = cpu_data.at[0, 'Running']
    post_value = cpu_data.at[0, 'Post']
    total_value = cpu_data.at[0, 'Total']

    # Print the values
    print("     - Pre     : ", pre_value)
    print("     - Running : ", running_value)
    print("     - Post    : ", post_value)
    print("     - Total   : ", total_value)

    # DIC
    if inla_data['dic']:
        dic_data = inla_data['dic']
        print("\n")
        print("     DIC:")
        print("     ----")
        print("     - DIC           : ", dic_data['dic'])
        print("     - Mean Deviance : ", dic_data['mean.deviance'])
        print("     - Deviance Mean : ", dic_data['deviance.mean'])


    # Marginal Likelihood
    if inla_data['mlik'] is not None:
        mlik_data = inla_data['mlik']
        print("\n")
        print("     Marginal Likelihood:")
        print("     --------------------")
        print("     - log marginal-likelihood (integration): ", mlik_data.iloc[0, 0])
        print("     - log marginal-likelihood (Gaussian)   : ", mlik_data.iloc[1, 0])
        print('\n')
        return inla_data
    

def processing(res):
    inla_dict = {}
    tmp_names = ['names.fixed','summary.fixed', 'marginals.fixed', 'cpo', 'mlik', 'gcpo', 'dic', 'waic',
                'cpu.used', 'summary.random', 'marginals.random', 'summary.hyperpar', 'summary.fitted.values',
                'summary.linear.predictor', 'marginals.hyperpar',  'marginals.linear.predictor', 'marginals.fitted.values', 'residuals']
    for name in tmp_names:
        convert_types(name, res, inla_dict, None)
    return inla_dict

def inla(formula, **kwargs):

    allowed_keys = [
        'data', 'control_family','family', 'verbose', 'scale', 'E', 'Ntrials', 'control_inla', 'control_fixed', 'control_compute', 
        'control_predictor', 'control_expert', 'control_family', 'control_hazard', 'control_lincomb', 
        'control_mode', 'control_results', 'control_update'
    ]

    for key in kwargs:
        if key not in allowed_keys:
            raise ValueError(f"Invalid key '{key}' in kwargs. Allowed keys are: {allowed_keys}")

    if 'data' in kwargs:
        data_for_model = kwargs['data']
        data_for_model, graph_data = separate_graph_dataframes(data_for_model)
        graph_data = convert_to_sparse_matrix(graph_data)
        inla_call = formula_from_dict(formula, data_for_model, graph_data)
        kwargs['data'] = convert_dic_to_r_list(data_for_model, graph_data)

    if 'control_family' in kwargs:
        dict_hyper_lev1 = {}
        dict_hyper_lev2 = {}

        if 'hyper' in kwargs['control_family']:
            for key, value in kwargs['control_family']['hyper'].items():
                tmp = {}
                for subkey, subvalue in value.items():
                    tmp[subkey] = py_vec_to_r_vec(subvalue, subkey)
                dict_hyper_lev1[key] = robjects.ListVector(tmp)

            dict_hyper_lev2 = robjects.ListVector(dict_hyper_lev2)
            dict_hyper_lev2.rx2['hyper'] = robjects.ListVector(dict_hyper_lev1)

        if 'variant' in kwargs['control_family']:
            if not isinstance(dict_hyper_lev2, ListVector):
                dict_hyper_lev2 = robjects.ListVector(dict_hyper_lev2)
            dict_hyper_lev2.rx2['variant'] = kwargs['control_family']['variant']

        if 'beta_censor_value' in kwargs['control_family']:
            if not isinstance(dict_hyper_lev2, ListVector):
                dict_hyper_lev2 = robjects.ListVector(dict_hyper_lev2)
            dict_hyper_lev2.rx2['beta.censor.value'] = kwargs['control_family']['beta_censor_value']

        if 'link' in kwargs['control_family']:
            if not isinstance(dict_hyper_lev2, ListVector):
                dict_hyper_lev2 = robjects.ListVector(dict_hyper_lev2)
            dict_hyper_lev2.rx2['link'] = robjects.ListVector(kwargs['control_family']['link'])

        kwargs['control.family'] = dict_hyper_lev2
        del kwargs['control_family']
    
    if 'scale' in kwargs:
        kwargs['scale'] = robjects.FloatVector(kwargs['scale'])

    if 'E' in kwargs:
        kwargs['E'] = robjects.FloatVector(kwargs['E'])

    if 'Ntrials' in kwargs:
        kwargs['Ntrials'] = robjects.FloatVector(kwargs['Ntrials'])

    process_control_inla_options(kwargs)
    process_control_fixed_options(kwargs)
    process_control_compute_options(kwargs)
    process_control_predictor_options(kwargs)
    process_control_expert_options(kwargs)
    process_control_family_options(kwargs)
    process_control_hazard_options(kwargs)
    process_control_lincomb_options(kwargs)
    process_control_mode_options(kwargs)
    process_control_results_options(kwargs)
    process_control_update_options(kwargs)
    
    args_dict = dict(kwargs)
    print("<o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o>")
    print("|                                                                            |")
    print("|                      Thanks for using Py-INLA!                             |")
    print("|                                                                            |")
    print("<o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o>")
    print("\n")
    print("   o Py-INLA version: 9-6-2024")
    print("   o INLA version: ", get_inla_version())
    print("   o Python version: ", sys.version)
    print("\n")

    res = call.inla(inla_call, **args_dict)
    print(inla_call)
    results = summary(res)
    print("\n   o Inference process is completed.")
    print("   o If you need assistance, please contact us at esmail@r-inla.org \n")
    print("<o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o><o>\n")
    return results

def inla_tmarginal_safe_mode(fun_str, x_values, y_values):
    fun = r(fun_str)
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))
    call_tmarginal = r['inla.tmarginal']
    result = call_tmarginal(fun, r_matrix)
    get_x_values = result.rx2('x')
    get_y_values = result.rx2('y')
    data = {'x': np.array(get_x_values), 'y': np.array(get_y_values)}
    df = pd.DataFrame(data)
    return df


def inla_tmarginal(fun_str, *args, safe_mode=True):

    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
            data = args[0]
            if 'x' in data.columns and 'y' in data.columns:
                x_values = data['x'].tolist()
                y_values = data['y'].tolist()
            else:
                raise ValueError("DataFrame must contain 'x' and 'y' columns.")

    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']

    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_tmarginal_safe_mode(fun_str, x_values, y_values)
    

def inla_qmarginal_safe_mode(range, x_values, y_values):

    R_range = FloatVector(range)
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))
    call_tmarginal = r['inla.qmarginal']
    result = call_tmarginal(R_range, r_matrix)

    if not isinstance(result, np.ndarray):
        return None

    return result


def inla_qmarginal(range, *args, safe_mode=True):

    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
            data = args[0]
            if 'x' in data.columns and 'y' in data.columns:
                x_values = data['x'].tolist()
                y_values = data['y'].tolist()
            else:
                raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_qmarginal_safe_mode(range, x_values, y_values)


def convert_r_list_to_py_dict(r_list):
    py_dict = {}
    for name in r_list.names:
        py_dict[name] = r_list.rx2(name)[0]
    return py_dict


def inla_zmarginal_safe_mode(x_values, y_values):
    original_stdout = sys.stdout 
    with open(os.devnull, 'w') as devnull:
        sys.stdout = devnull  
        try:
            r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))
            call_tmarginal = r['inla.zmarginal']
            result = convert_r_list_to_py_dict(call_tmarginal(r_matrix))
        finally:
            sys.stdout = original_stdout 

    return result


def inla_zmarginal(*args):
    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
        data = args[0]
        if 'x' in data.columns and 'y' in data.columns:
            x_values = data['x'].tolist()
            y_values = data['y'].tolist()
        else:
            raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    elif len(args) == 1 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")
    return inla_zmarginal_safe_mode(x_values, y_values)


def inla_pmarginal_safe_mode(q, x_values, y_values):
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))

    call_pmarginal = r['inla.pmarginal']
    result = call_pmarginal([q], r_matrix)
    return result[0]

def inla_pmarginal(q, *args, safe_mode=True):

    q = float(q)
    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
        data = args[0]
        if 'x' in data.columns and 'y' in data.columns:
            x_values = data['x'].tolist()
            y_values = data['y'].tolist()
        else:
            raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_pmarginal_safe_mode(q, x_values, y_values)
    

def inla_hpdmarginal_safe_mode(q, x_values, y_values):
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))
    call_hpdmarginal = r['inla.hpdmarginal']
    result = call_hpdmarginal(FloatVector([q]), r_matrix)
    result_list = list(result) if result else [None, None]
    df = pd.DataFrame([result_list], columns=["low", "high"])
    df.index = [f"level:{q}"]

    return df

def inla_hpdmarginal(q, *args, safe_mode=True):
    q = float(q)
    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
        data = args[0]
        if 'x' in data.columns and 'y' in data.columns:
            x_values = data['x'].tolist()
            y_values = data['y'].tolist()
        else:
            raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_hpdmarginal_safe_mode(q, x_values, y_values)
    
def inla_emarginal_safe_mode(fun_str, x_values, y_values):
    fun = r(fun_str)
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))
    call_emarginal = r['inla.emarginal']
    result = call_emarginal(fun, r_matrix)
    get_x_values = result.rx2('x')
    get_y_values = result.rx2('y')
    data = {'x': np.array(get_x_values), 'y': np.array(get_y_values)}
    df = pd.DataFrame(data)
    return df

def inla_emarginal(fun_str, *args, safe_mode=True):
    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
            data = args[0]
            if 'x' in data.columns and 'y' in data.columns:
                x_values = data['x'].tolist()
                y_values = data['y'].tolist()
            else:
                raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_emarginal_safe_mode(fun_str, x_values, y_values)
    
def inla_emarginal_safe_mode(fun_str, x_values, y_values):
    fun = r(fun_str)
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))
    call_emarginal = r['inla.emarginal']
    result = call_emarginal(fun, r_matrix)
    return result[0]

def inla_emarginal(fun_str, *args, safe_mode=True):
    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
            data = args[0]
            if 'x' in data.columns and 'y' in data.columns:
                x_values = data['x'].tolist()
                y_values = data['y'].tolist()
            else:
                raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_emarginal_safe_mode(fun_str, x_values, y_values)

def inla_mmarginal_safe_mode(x_values, y_values):
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))

    call_mmarginal = r['inla.mmarginal']
    result = call_mmarginal(r_matrix)
    return result[0]

def inla_mmarginal(*args, safe_mode=True):
    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
            data = args[0]
            if 'x' in data.columns and 'y' in data.columns:
                x_values = data['x'].tolist()
                y_values = data['y'].tolist()
            else:
                raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_mmarginal_safe_mode(x_values, y_values)
    
def inla_posterior_sample(num_samples, model, selection, intern=False, use_improved_mean=True,
                          add_names=True, seed=0, num_threads=None, verbose=False):
    r_selection = ListVector({k: BoolVector([v]) for k, v in selection.items()})
    if num_threads is None:
        num_threads = robjects.r('NULL')

    result = robjects.r['inla.posterior.sample'](
        n=num_samples,
        result=model,
        selection=r_selection,
        intern=intern,
        use_improved_mean=use_improved_mean,
        add_names=add_names,
        seed=seed,
        num_threads=num_threads,
        verbose=verbose
    )
    return convert_r_sample_to_python(result)

def inla_hyperpar_sample(num_samples, model):
    suppress_messages = robjects.r['suppressMessages']
    result = suppress_messages(robjects.r['inla.hyperpar.sample'](n=num_samples, result=model))
    n_rows, n_cols = result.dim
    result_np = np.array(result)
    col_names = ['hyperpar' + str(i) for i in range(1, n_cols + 1)]
    result_df = pd.DataFrame(result_np, columns=col_names)

    return result_df


def inla_posterior_sample_and_eval(num_samples, model, intern=False, use_improved_mean=True,
                          add_names=True, seed=0, num_threads=None, verbose=False, fun=''):
    if num_threads is None:
        num_threads = robjects.r('NULL')
    result1 = robjects.r['inla.posterior.sample'](
        n=num_samples,
        result=model,
        intern=intern,
        use_improved_mean=use_improved_mean,
        add_names=add_names,
        seed=seed,
        num_threads=num_threads,
        verbose=verbose
    )
    if fun:
        r_fun = r(fun)


    result2 = robjects.r['inla.posterior.sample.eval'](r_fun, result1)
    n_rows, n_cols = result2.dim
    result_np = np.array(result2)

    col_names = ['hyperpar' + str(i) for i in range(1, n_cols + 1)]
    result_df = pd.DataFrame(result_np, columns=col_names)

    return result_df
