# -------------------------------------------------------------------
# File: controls.py
# Author: Esmail Abdul Fattah
# Email: esmail@r-inla.org
# 
# Copyright (c) 2024 [Esmail Abdul Fattah]. All rights reserved.
# 
# This code is intended solely for use in the QGINLA project. 
# Unauthorized copying, editing, or distribution of this file, 
# via any medium, is strictly prohibited without prior written
# permission from the author.
# -------------------------------------------------------------------

from qginla.pyinla.library.utils import *

def process_control_inla_options(kwargs):
    if 'control_inla' in kwargs:
        cc_dict_hyper_lev2 = {}

        for key, value in kwargs['control_inla'].items():
            r_key = key.replace('_', '.')

            if isinstance(value, str):
                value = value.replace('_', '.')
            
            if not isinstance(cc_dict_hyper_lev2, robjects.ListVector):
                cc_dict_hyper_lev2 = robjects.ListVector(cc_dict_hyper_lev2)
            
            cc_dict_hyper_lev2.rx2[r_key] = value

        kwargs['control.inla'] = cc_dict_hyper_lev2
        print(kwargs['control.inla'])
        del kwargs['control_inla']


def process_control_fixed_options(kwargs):
    if 'control_fixed' in kwargs:
        cc_dict_hyper_lev2 = {}

        for key, value in kwargs['control_fixed'].items():
            r_key = key.replace('_', '.')
            
            if isinstance(value, str):
                value = value.replace('_', '.')
            if not isinstance(cc_dict_hyper_lev2, robjects.ListVector):
                cc_dict_hyper_lev2 = robjects.ListVector(cc_dict_hyper_lev2)
            cc_dict_hyper_lev2.rx2[r_key] = value

        kwargs['control.fixed'] = cc_dict_hyper_lev2
        del kwargs['control_fixed']


def process_control_compute_options(kwargs):
    if 'control_compute' in kwargs:
        cc_dict_hyper_lev2 = {}

        for key, value in kwargs['control_compute'].items():
            r_key = key.replace('_', '.')
            
            if isinstance(value, str):
                value = value.replace('_', '.')

            if not isinstance(cc_dict_hyper_lev2, robjects.ListVector):
                cc_dict_hyper_lev2 = robjects.ListVector(cc_dict_hyper_lev2)
            
            cc_dict_hyper_lev2.rx2[r_key] = value

        kwargs['control.compute'] = cc_dict_hyper_lev2
        del kwargs['control_compute']


def process_control_predictor_options(kwargs):
    if 'control_predictor' in kwargs:
        cc_dict_hyper_lev2 = {}

        for key, value in kwargs['control_predictor'].items():
            r_key = key.replace('_', '.')

            if isinstance(value, str):
                value = value.replace('_', '.')

            if not isinstance(cc_dict_hyper_lev2, robjects.ListVector):
                cc_dict_hyper_lev2 = robjects.ListVector(cc_dict_hyper_lev2)
            
            cc_dict_hyper_lev2.rx2[r_key] = value

        kwargs['control.predictor'] = cc_dict_hyper_lev2
        del kwargs['control_predictor']

def process_control_expert_options(kwargs):
    if 'control_expert' in kwargs:
        cc_dict_hyper_lev2 = {}

        for key, value in kwargs['control_expert'].items():
            r_key = key.replace('_', '.')

            if isinstance(value, str):
                value = value.replace('_', '.')
            if not isinstance(cc_dict_hyper_lev2, robjects.ListVector):
                cc_dict_hyper_lev2 = robjects.ListVector(cc_dict_hyper_lev2)
            
            cc_dict_hyper_lev2.rx2[r_key] = value

        kwargs['control.expert'] = cc_dict_hyper_lev2
        del kwargs['control_expert']


def process_control_family_options(kwargs):
    if 'control_family' in kwargs:
        cc_dict_hyper_lev2 = {}

        for key, value in kwargs['control_family'].items():
            r_key = key.replace('_', '.')

            if isinstance(value, str):
                value = value.replace('_', '.')

            if not isinstance(cc_dict_hyper_lev2, robjects.ListVector):
                cc_dict_hyper_lev2 = robjects.ListVector(cc_dict_hyper_lev2)
            
            cc_dict_hyper_lev2.rx2[r_key] = value

        kwargs['control.family'] = cc_dict_hyper_lev2
        del kwargs['control_family']

def process_control_hazard_options(kwargs):
    if 'control_hazard' in kwargs:
        cc_dict_hyper_lev2 = {}

        for key, value in kwargs['control_hazard'].items():
            r_key = key.replace('_', '.')

            if isinstance(value, str):
                value = value.replace('_', '.')

            if not isinstance(cc_dict_hyper_lev2, robjects.ListVector):
                cc_dict_hyper_lev2 = robjects.ListVector(cc_dict_hyper_lev2)
            
            cc_dict_hyper_lev2.rx2[r_key] = value

        kwargs['control.hazard'] = cc_dict_hyper_lev2
        del kwargs['control_hazard']


def process_control_lincomb_options(kwargs):
    if 'control_lincomb' in kwargs:
        cc_dict_hyper_lev2 = {}

        for key, value in kwargs['control_lincomb'].items():
            r_key = key.replace('_', '.')

            if isinstance(value, str):
                value = value.replace('_', '.')

            if not isinstance(cc_dict_hyper_lev2, robjects.ListVector):
                cc_dict_hyper_lev2 = robjects.ListVector(cc_dict_hyper_lev2)
            
            cc_dict_hyper_lev2.rx2[r_key] = value

        kwargs['control.lincomb'] = cc_dict_hyper_lev2
        del kwargs['control_lincomb']


def process_control_mode_options(kwargs):
    if 'control_mode' in kwargs:
        cc_dict_hyper_lev2 = {}

        for key, value in kwargs['control_mode'].items():
            r_key = key.replace('_', '.')

            if isinstance(value, str):
                value = value.replace('_', '.')

            if not isinstance(cc_dict_hyper_lev2, robjects.ListVector):
                cc_dict_hyper_lev2 = robjects.ListVector(cc_dict_hyper_lev2)
            
            cc_dict_hyper_lev2.rx2[r_key] = value

        kwargs['control.mode'] = cc_dict_hyper_lev2
        del kwargs['control_mode']


def process_control_results_options(kwargs):
    if 'control_results' in kwargs:
        cc_dict_hyper_lev2 = {}

        for key, value in kwargs['control_results'].items():
            r_key = key.replace('_', '.')

            if isinstance(value, str):
                value = value.replace('_', '.')

            if not isinstance(cc_dict_hyper_lev2, robjects.ListVector):
                cc_dict_hyper_lev2 = robjects.ListVector(cc_dict_hyper_lev2)
            
            cc_dict_hyper_lev2.rx2[r_key] = value

        kwargs['control.results'] = cc_dict_hyper_lev2
        del kwargs['control_results']


def process_control_update_options(kwargs):
    if 'control_update' in kwargs:
        cc_dict_hyper_lev2 = {}

        for key, value in kwargs['control_update'].items():
            r_key = key.replace('_', '.')

            if isinstance(value, str):
                value = value.replace('_', '.')
                
            if not isinstance(cc_dict_hyper_lev2, robjects.ListVector):
                cc_dict_hyper_lev2 = robjects.ListVector(cc_dict_hyper_lev2)
            
            cc_dict_hyper_lev2.rx2[r_key] = value

        kwargs['control.update'] = cc_dict_hyper_lev2
        del kwargs['control_update']

