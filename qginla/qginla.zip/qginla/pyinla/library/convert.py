
# -------------------------------------------------------------------
# File: convert.py
# Author: Esmail Abdul Fattah
# Email: esmail@r-inla.org
# 
# Copyright (c) 2024 [Esmail Abdul Fattah]. All rights reserved.
# 
# This code is intended solely for use in the QGINLA project. 
# Unauthorized copying, editing, or distribution of this file, 
# via any medium, is strictly prohibited without prior written
# permission from the author.
# -------------------------------------------------------------------


from qginla.pyinla.library.utils import *


def convert_series_to_R_float_vector(series):
    return FloatVector(series)

def convert_dataframe_to_r_vectors(df):
    r_vectors = {}
    for col_name in df.columns:
        #print(col_name)
        if df[col_name].dtype == 'float64' or df[col_name].dtype == 'int64':
            r_vectors[col_name] = FloatVector(df[col_name])
        elif df[col_name].dtype == 'bool':
            r_vectors[col_name] = BoolVector(df[col_name])
        elif df[col_name].dtype == 'object':  # Assuming 'object' dtype is string
            r_vectors[col_name] = StrVector(df[col_name])
        else:
            # For other data types, you can add more conditions
            raise ValueError(f"Data type of column '{col_name}' is not supported.")

    return r_vectors

def py_vec_to_r_vec(x, subkey):
    
    if subkey == 'initial':
        x = float(x)
    elif isinstance(x, list) or isinstance(x, npp.ndarray):
        x = robjects.FloatVector(x)
    return x


def convert_dic_to_dataframe(dic):
    converted_dic = {key: robjects.FloatVector(value) for key, value in dic.items()}
    data = robjects.DataFrame(converted_dic)
    return data


def convert_dic_to_r_list(dic, graphs):
    converted_dic = {}
    for key, value in dic.items():
        if isinstance(value, pd.Series):
            converted_dic[key] = robjects.FloatVector(value)
        elif isinstance(value, list):
            converted_dic[key] = robjects.FloatVector(value)
        elif isinstance(value, str):
            converted_dic[key] = robjects.StrVector([value])
        elif isinstance(value, np.ndarray):
            handle_matrix_conversion(key, value)
            converted_dic[key] = r[key]  # Access the R object after assignment
        elif scipy.sparse.issparse(value):
            handle_matrix_conversion(key, value)
            converted_dic[key] = r[key]  # Access the R object after assignment
        else:
            # Handle other types or raise an error
            raise TypeError(f"Conversion 'py2rpy' not defined for objects of type '{type(value)}'")

    converted_dic.update(graphs)

    r_list = robjects.ListVector(converted_dic)
    return r_list

def convert_r_sample_to_python(r_sample):
    python_results = []
    for sample in r_sample:
        hyperpar = sample.rx2('hyperpar')
        hyperpar_dict = {k: hyperpar.rx2(k)[0] for k in hyperpar.names}

        latent = sample.rx2('latent')
        latent_dict = {}
        if isinstance(latent, FloatMatrix):
            row_names = latent.rownames
            if row_names is not None:
                for i, var in enumerate(row_names):
                    # Remove everything after a colon
                    var_cleaned = var.split(':')[0]
                    latent_dict[var_cleaned] = latent.rx(i+1, True)[0]  # +1 because R is 1-indexed

        logdens = sample.rx2('logdens')
        logdens_dict = {k: logdens.rx2(k)[0] for k in logdens.names}

        sample_dict = {
            'hyperpar': hyperpar_dict,
            'latent': latent_dict,
            'logdens': logdens_dict
        }
        python_results.append(sample_dict)

    return python_results


def convert_python_sample_to_r(python_samples):
    r_samples = []
    for sample in python_samples:

        hyperpar = ListVector(sample['hyperpar'])
        latent_values = [v for v in sample['latent'].values()]
        latent_names = [k for k in sample['latent'].keys()]
        latent = FloatVector(latent_values)
        latent.names = StrVector(latent_names)
        logdens_values = [v for v in sample['logdens'].values()]
        logdens_names = [k for k in sample['logdens'].keys()]
        logdens = FloatVector(logdens_values)
        logdens.names = StrVector(logdens_names)
        sample_r = ListVector({
            'hyperpar': hyperpar,
            'latent': latent,
            'logdens': logdens
        })
        r_samples.append(sample_r)
    
    return r_samples


def dict_to_r_list(py_dict):
    r_list = ListVector({k: BoolVector([v]) for k, v in py_dict.items()})
    return r_list

def handle_matrix_conversion(key, matrix):

    numpy2ri.activate()
    if isinstance(matrix, np.ndarray):  
        r_matrix = numpy2ri.py2rpy(matrix)
        r.assign(key, r_matrix)
    elif scipy.sparse.issparse(matrix):  
        r_matrix = scipy_sparse_to_dgTMatrix(matrix)
        r.assign(key, r_matrix)
    else:
        raise ValueError(f"Unsupported matrix type for key '{key}'")
    numpy2ri.deactivate()



def scipy_sparse_to_dgTMatrix(sparse_matrix):
    Matrix = importr('Matrix')
    coo = sparse_matrix.tocoo()
    data = FloatVector(coo.data)
    i = IntVector(coo.row + 1)  
    j = IntVector(coo.col + 1) 
    return Matrix.sparseMatrix(i=i, j=j, x=data, dims=IntVector(sparse_matrix.shape))

