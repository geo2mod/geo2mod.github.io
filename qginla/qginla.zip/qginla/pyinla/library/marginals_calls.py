




def inla_tmarginal_safe_mode(fun_str, x_values, y_values):
    # Convert the string to an R function
    fun = r(fun_str)

    # Create an R matrix from the combined values
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))

    # Call the R function
    call_tmarginal = r['inla.tmarginal']
    result = call_tmarginal(fun, r_matrix)
    get_x_values = result.rx2('x')
    get_y_values = result.rx2('y')

    #Convert to Pandas DataFrame
    data = {'x': np.array(get_x_values), 'y': np.array(get_y_values)}
    df = pd.DataFrame(data)
    
    return df

def inla_tmarginal(fun_str, *args, safe_mode=True):

    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
            data = args[0]
            if 'x' in data.columns and 'y' in data.columns:
                x_values = data['x'].tolist()
                y_values = data['y'].tolist()
            else:
                raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    # Check if only one argument is provided and it's a dictionary-like object
    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    # Check if two arguments are provided
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_tmarginal_safe_mode(fun_str, x_values, y_values)
    


def convert_r_list_to_py_dict(r_list):
    py_dict = {}
    for name in r_list.names:
        py_dict[name] = r_list.rx2(name)[0]
    return py_dict


def inla_zmarginal_safe_mode(x_values, y_values):
    # Suppressing the output
    original_stdout = sys.stdout  # Save a reference to the original standard output
    with open(os.devnull, 'w') as devnull:
        sys.stdout = devnull  # Redirect the output to null device
        try:
            # Create an R matrix from the combined values
            r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))

            # Call the R function
            call_tmarginal = r['inla.zmarginal']
            result = convert_r_list_to_py_dict(call_tmarginal(r_matrix))
        finally:
            sys.stdout = original_stdout  # Reset the standard output to its original value

    return result


def inla_zmarginal(*args):
    # Check if only one argument is provided and it's a pandas DataFrame
    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
        data = args[0]
        if 'x' in data.columns and 'y' in data.columns:
            x_values = data['x'].tolist()
            y_values = data['y'].tolist()
        else:
            raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    # Check if only one argument is provided and it's a dictionary-like object
    elif len(args) == 1 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    # Check if two arguments are provided
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    # Call the safe mode function and return its result
    return inla_zmarginal_safe_mode(x_values, y_values)


def inla_pmarginal_safe_mode(q, x_values, y_values):

    # Create an R matrix from the combined values
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))

    call_pmarginal = r['inla.pmarginal']
    result = call_pmarginal([q], r_matrix)
    return result[0]

def inla_pmarginal(q, *args, safe_mode=True):

    q = float(q)
    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
        data = args[0]
        if 'x' in data.columns and 'y' in data.columns:
            x_values = data['x'].tolist()
            y_values = data['y'].tolist()
        else:
            raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    # Check if only one argument is provided and it's a dictionary-like object
    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    # Check if two arguments are provided
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_pmarginal_safe_mode(q, x_values, y_values)
    

def inla_hpdmarginal_safe_mode(q, x_values, y_values):
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))

    call_hpdmarginal = r['inla.hpdmarginal']

    result = call_hpdmarginal(FloatVector([q]), r_matrix)

    # Convert the result to a Python list
    result_list = list(result) if result else [None, None]

    # Create a DataFrame from the result
    df = pd.DataFrame([result_list], columns=["low", "high"])

    # Set the row index to the level (value of q)
    df.index = [f"level:{q}"]

    return df

def inla_hpdmarginal(q, *args, safe_mode=True):

    q = float(q)
    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
        data = args[0]
        if 'x' in data.columns and 'y' in data.columns:
            x_values = data['x'].tolist()
            y_values = data['y'].tolist()
        else:
            raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    # Check if only one argument is provided and it's a dictionary-like object
    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    # Check if two arguments are provided
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_hpdmarginal_safe_mode(q, x_values, y_values)
    


def inla_emarginal_safe_mode(fun_str, x_values, y_values):
    # Convert the string to an R function
    fun = r(fun_str)

    # Create an R matrix from the combined values
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))

    # Call the R function
    call_emarginal = r['inla.emarginal']
    result = call_emarginal(fun, r_matrix)
    get_x_values = result.rx2('x')
    get_y_values = result.rx2('y')

    #Convert to Pandas DataFrame
    data = {'x': np.array(get_x_values), 'y': np.array(get_y_values)}
    df = pd.DataFrame(data)
    
    return df

def inla_emarginal(fun_str, *args, safe_mode=True):

    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
            data = args[0]
            if 'x' in data.columns and 'y' in data.columns:
                x_values = data['x'].tolist()
                y_values = data['y'].tolist()
            else:
                raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    # Check if only one argument is provided and it's a dictionary-like object
    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    # Check if two arguments are provided
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_emarginal_safe_mode(fun_str, x_values, y_values)
    
def inla_emarginal_safe_mode(fun_str, x_values, y_values):
    # Convert the string to an R function
    fun = r(fun_str)

    # Create an R matrix from the combined values
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))

    # Call the R function
    call_emarginal = r['inla.emarginal']
    result = call_emarginal(fun, r_matrix)
    return result[0]

def inla_emarginal(fun_str, *args, safe_mode=True):

    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
            data = args[0]
            if 'x' in data.columns and 'y' in data.columns:
                x_values = data['x'].tolist()
                y_values = data['y'].tolist()
            else:
                raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    # Check if only one argument is provided and it's a dictionary-like object
    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    # Check if two arguments are provided
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_emarginal_safe_mode(fun_str, x_values, y_values)


def inla_mmarginal_safe_mode(x_values, y_values):

    # Create an R matrix from the combined values
    r_matrix = r['data.frame'](x=FloatVector(x_values), y=FloatVector(y_values))

    call_mmarginal = r['inla.mmarginal']
    result = call_mmarginal(r_matrix)
    return result[0]

def inla_mmarginal(*args, safe_mode=True):

    if len(args) == 1 and isinstance(args[0], pd.DataFrame):
            data = args[0]
            if 'x' in data.columns and 'y' in data.columns:
                x_values = data['x'].tolist()
                y_values = data['y'].tolist()
            else:
                raise ValueError("DataFrame must contain 'x' and 'y' columns.")
    # Check if only one argument is provided and it's a dictionary-like object
    elif len(args) == 2 and isinstance(args[0], dict):
        data = args[0]
        x_values = data['x']
        y_values = data['y']
    # Check if two arguments are provided
    elif len(args) == 2:
        x_values, y_values = args
    else:
        raise ValueError("Invalid arguments. Provide either a DataFrame, a dictionary-like object, or two lists (x_values, y_values).")

    if safe_mode:
        return inla_mmarginal_safe_mode(x_values, y_values)
    