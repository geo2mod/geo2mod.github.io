
# -------------------------------------------------------------------
# File: convert_types.py
# Author: Esmail Abdul Fattah
# Email: esmail@r-inla.org
# 
# Copyright (c) 2024 [Esmail Abdul Fattah]. All rights reserved.
# 
# This code is intended solely for use in the QGINLA project. 
# Unauthorized copying, editing, or distribution of this file, 
# via any medium, is strictly prohibited without prior written
# permission from the author.
# -------------------------------------------------------------------

from qginla.pyinla.library.utils import *
from qginla.pyinla.library.convert import *
from qginla.pyinla.library.controls import *
from qginla.pyinla.library.output import *

def recurse_r_tree(data):

    r_dict_types = [DataFrame, ListVector]
    r_array_types = [FloatVector, IntVector, Matrix, FloatMatrix, BoolVector]
    r_list_types = [StrVector]
    
    if type(data) in r_dict_types:
        #print(data)
        names = list(data.names) if data.names else []  # Convert data.names to a list if it exists
        return OrderedDict(zip(names, [recurse_r_tree(elt) for elt in iter(data)]))
    elif type(data) in r_list_types:
        return [recurse_r_tree(elt) for elt in iter(data)]
    elif type(data) in r_array_types:
        return np.array(data)
    elif type(data) is NULLType:
        return None  # Handle NULLType separately
    elif type(data) is SignatureTranslatedFunction:
        return str(data)  # Default behavior for function objects (you may customize this based on your needs)
    elif type(data) is Formula:
        return str(data)  # Default behavior for formula objects (you may customize this based on your needs)
    elif type(data) is Environment:
        return str(data)  # Default behavior for environment objects (you may customize this based on your needs)
    elif type(data) is RS4:
        return str(data)  # Default behavior for RS4 objects (you may customize this based on your needs)
    else:
        if hasattr(data, "rclass"):  # An unsupported R class
            raise KeyError('Could not proceed, type {} is not defined '
                           'to add support for this type, just add it to the imports '
                           'and to the appropriate type list above'.format(type(data)))
        else:
            return data  # We reached the end of recursion

def contruct_dictionary_strings(name, object, inla_dict):

    name_R = StrVector([name])
    if name == 'names.fixed':
        #print(object.rx[name][0])
        inla_dict['names.fixed'] = list(robjects.r['as.character'](object.rx[name_R][0]))
        inla_dict['names.fixed'] = ['intercept' if name == '(Intercept)' else name for name in inla_dict['names.fixed']]

    elif name == 'logfile':     
        inla_dict['logfile'] = object.rx['logfile'][0]

    elif name == 'call':     
        inla_dict['call'] = object.rx['call'][0]

def contruct_dictionary_dataframes(name, object, inla_dict, extrargument):
    column_names = {}
    row_names = {}
    if hasattr(object, 'colnames') and object.colnames is not None:
        column_names = list(object.colnames)
    if hasattr(object, 'rownames') and object.rownames is not None:
        row_names = list(object.rownames)
    df = pd.DataFrame(object)
    df.index = column_names
    df.columns = row_names
    inla_dict[name] = df      

def contruct_dictionary_floats(name, object, inla_dict):

    if isinstance(object, FloatMatrix):
        
        row_names = {}
        column_names = {}        
        if type(object.colnames) is not NULLType and type(object.rownames) is NULLType:
            column_names = list(object.colnames)
            df = pd.DataFrame(columns=range(len(column_names)))
            new_dic = {}
            new_dic['x'] = np.array(object.rx(True, 1))
            new_dic['y'] = np.array(object.rx(True, 2))

            inla_dict[str(name)] = new_dic

        else:
            if type(object.rownames) is not NULLType:
                if False:
                    row_names = list(object.rownames)
                    df = pd.DataFrame(object)
                    df.index = row_names
                    inla_dict[name] = df 
                    if type(object.colnames) is not NULLType:
                        df.columns = list(object.colnames)
                else:
                    row_names = list(object.rownames)
                    if type(object.colnames) is not NULLType:
                        col_names = list(object.colnames)
                    else:
                        col_names = None
                    data = np.array(object)
                    df = pd.DataFrame(data, index=row_names, columns=col_names)
                    inla_dict[name] = df

            else:
                df = pd.DataFrame(object)
                

            if name == 'mlik':
                new_column_names = {col: name for col in df.columns}
                df = df.rename(columns=new_column_names)
            
            inla_dict[str(name)] = df 


    elif isinstance(object, FloatVector):
        row_names = {}           
        if hasattr(object, 'names') and object.names is not None:
            if type(object.names) is not NULLType:  
                row_names = object.names
                df = pd.DataFrame(object)
                df.index = row_names
                new_column_names = {col: name for col in df.columns}
                df = df.rename(columns=new_column_names)
                inla_dict[name] = df
            else: 
                df = pd.DataFrame(object)
                new_column_names = {col: name for col in df.columns}
                df = df.rename(columns=new_column_names)
                inla_dict[name] = df


def contruct_dictionary_RS4(name, object, inla_dict):
    inla_dict[name] = str(object) 

def contruct_dictionary_intVecs(name, object, inla_dict):
    inla_dict[name] = list(object) 

def contruct_dictionary_booleans(name, object, inla_dict):
    inla_dict[name] = list(object)

def convert_types(name, object, inla_dict, extrargument):
    
        name_R = StrVector([name])
        if name in ['names.fixed']: 
            contruct_dictionary_strings(name, object, inla_dict)
        elif isinstance(object.rx[name_R], DataFrame):
            contruct_dictionary_dataframes(name, object.rx[name_R], inla_dict, extrargument)
        elif isinstance(object.rx[name_R], FloatVector):
            contruct_dictionary_floats(name, object.rx[name_R], inla_dict)
        elif type(object.rx[name_R]) is NULLType:
            pass
        elif type(object.rx[name_R]) is RS4:
            contruct_dictionary_RS4(name, object.rx[name_R], inla_dict)
        elif isinstance(object.rx[name_R], IntVector):
            contruct_dictionary_intVecs(name, object.rx[name_R], inla_dict)
        elif isinstance(object.rx[name_R], BoolVector):
            contruct_dictionary_booleans(name, object.rx[name_R], inla_dict)
        elif isinstance(object.rx[name_R], ListVector):   
            x = object.rx[name_R][0]
            if name == 'marginals.fixed':
                get_marginals_fixed(name, object, inla_dict)
            elif name == 'marginals.random':
                get_marginals_random(name, object, inla_dict)
            elif name == 'marginals.hyperpar':
                get_marginals_hyperpar(name, object, inla_dict)
            elif name == 'marginals.linear.predictor':
                get_marginals_linear_predictor(name, object, inla_dict)
            elif name == 'marginals.fitted.values':
                get_marginals_fitted_values(name, object, inla_dict)
            elif name == 'residuals':
                get_residuals(name, object, inla_dict)
            elif name == 'cpo':
                get_cpo(inla_dict, name, x)
            elif name == 'gcpo':
                get_gcpo(inla_dict, name, x)
            elif name == 'dic':
                get_dic(inla_dict, name, x)
            elif name == 'waic':
                get_waic(inla_dict, name, x)
            elif name == 'mlik':
                get_mlik(object, inla_dict, name)
            elif name == 'cpu.used':
                get_cpuused(object, inla_dict, name)
            elif name in ['summary.fixed'] :
                get_summary_fixed(name, object, inla_dict)
            elif name in ['summary.random'] :
                get_summary_random(name, object, inla_dict)
            elif name in ['summary.hyperpar'] :
                get_summary_hyperpar(name, object, inla_dict)
            elif name in ['summary.fitted.values'] :
                get_summary_fitted_values(name, object, inla_dict)
            elif name in ['summary.linear.predictor'] :
                get_summary_linear_predictor(name, object, inla_dict)
            else: 
                pass
        else: 
                pass

def inla_dataframe(dic):
    converted_dic = {key: robjects.FloatVector(value) for key, value in dic.items()}
    data = robjects.DataFrame(converted_dic)
    return data


