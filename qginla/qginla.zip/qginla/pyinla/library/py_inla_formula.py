# -------------------------------------------------------------------
# File: py_inla_formula.py
# Author: Esmail Abdul Fattah
# Email: esmail@r-inla.org
# 
# Copyright (c) 2024 [Esmail Abdul Fattah]. All rights reserved.
# 
# This code is intended solely for use in the QGINLA project. 
# Unauthorized copying, editing, or distribution of this file, 
# via any medium, is strictly prohibited without prior written
# permission from the author.
# -------------------------------------------------------------------

from qginla.pyinla.library.convert_types import *


def formula(inla_for):
    return robjects.Formula(inla_for)

def formula_adv(inla_for):
    return robjects.Formula(inla_for)

def handle_fixed_effects(variables_dict):
    if 'fixed' in variables_dict:
        fixed_effects = variables_dict['fixed']
        if 'random' not in variables_dict:
            variables_dict['random'] = {}

        if isinstance(fixed_effects, dict):
            old_style_fixed_effects = []  # List to hold old style fixed effects
            for effect, details in list(fixed_effects.items()):
                if isinstance(details, dict) and 'model' in details:
                    variables_dict['random'][effect] = fixed_effects.pop(effect)
                else:
                    old_style_fixed_effects.extend(details)

            if old_style_fixed_effects:
                variables_dict['fixed'] = old_style_fixed_effects
            else:
                del variables_dict['fixed']

        elif isinstance(fixed_effects, list):
            pass  # Old style: fixed effects as a list (no action needed)
    
    if 'random' in variables_dict and not variables_dict['random']:
        del variables_dict['random']

    return variables_dict


def create_hyper_string_fixed(hyper):
    hyper_parts = []
    for key, value in hyper.items():
        if isinstance(value, dict):
            nested_parts = []
            for sub_key, sub_value in value.items():
                if isinstance(sub_value, list):
                    sub_value_str = ", ".join([format_prior_name(v) if sub_key == 'prior' else str(v) for v in sub_value])
                    nested_parts.append(f"{sub_key} = c({sub_value_str})")
                else:
                    formatted_sub_value = format_prior_name(sub_value) if sub_key == 'prior' else sub_value
                    nested_parts.append(f"{sub_key} = \"{formatted_sub_value}\"")
            nested_str = "list(" + ", ".join(nested_parts) + ")"
            hyper_parts.append(f"{key} = {nested_str}")
        elif isinstance(value, list):
            list_str = ", ".join([format_prior_name(v) if key == 'prior' else str(v) for v in value])
            hyper_parts.append(f"{key} = c({list_str})")
        else:
            formatted_value = format_prior_name(value) if key == 'prior' else value
            hyper_parts.append(f"{key} = \"{formatted_value}\"")
    return "list(" + ", ".join(hyper_parts) + ")"


def latent_field_iid(effect_details, random_effect_str, data_for_model):
    if 'hyper' in effect_details:
        hyper = effect_details['hyper']
        hyper_str = create_hyper_string_fixed(hyper)
        random_effect_str += f", hyper = {hyper_str}"
    if 'weights' in effect_details:
        weights = effect_details['weights']
        random_effect_str += f", weights = {weights}"
        if not weights in data_for_model:
            raise ValueError(f"Key '{weights}' not found in data")
    
    return random_effect_str  # Return the updated string

def latent_field_rw1(effect_details, random_effect_str, data_for_model):

    if 'hyper' in effect_details:
        hyper = effect_details['hyper']
        hyper_str = create_hyper_string_fixed(hyper)
        random_effect_str += f", hyper = {hyper_str}"
        
    if 'weights' in effect_details:
        weights = effect_details['weights']
        random_effect_str += f", weights = {weights}"
        if not weights in data_for_model:
            raise ValueError(f"Key '{weights}' not found in data")

    if 'scale.model' in effect_details:
        scaling = effect_details['scale.model']
        scaling = "TRUE" if scaling else "FALSE"
        random_effect_str += f", scale.model = {scaling}"


    return random_effect_str  # Return the updated string


def latent_field_besag(effect_details, random_effect_str, data_for_model):
    if 'hyper' in effect_details:
        hyper = effect_details['hyper']
        hyper_str = create_hyper_string_fixed(hyper)
        random_effect_str += f", hyper = {hyper_str}"

    if 'weights' in effect_details:
        weights = effect_details['weights']
        random_effect_str += f", weights = {weights}"
        if not weights in data_for_model:
            raise ValueError(f"Key '{weights}' not found in data")
        
    if 'scale.model' in effect_details:
        scaling = effect_details['scale.model']
        scaling = "TRUE" if scaling else "FALSE"
        random_effect_str += f", scale.model = {scaling}"

    if 'adjust_for_con_comp' in effect_details:
        con_comp = effect_details['adjust_for_con_comp']
        con_comp = "TRUE" if con_comp else "FALSE"
        random_effect_str += f", adjust.for.con.comp = {con_comp}"

    target_keys = ['graph']
    Cmatrixs_key = None

    for key in effect_details:
        if key in target_keys:
            Cmatrixs_key = effect_details[key]
            break

    if Cmatrixs_key is not None:
        random_effect_str += f", graph = {Cmatrixs_key}"
        if not Cmatrixs_key in data_for_model:
            raise ValueError(f"Key '{Cmatrixs_key}' not found in data_for_model")
    
    return random_effect_str

def latent_field_bym(effect_details, random_effect_str, data_for_model, graph_data):
    """Create a string snippet for additional parameters"""

    if 'hyper' in effect_details:
        hyper = effect_details['hyper']
        hyper_str = create_hyper_string_fixed(hyper)
        random_effect_str += f", hyper = {hyper_str}"

    if 'weights' in effect_details:
        weights = effect_details['weights']
        random_effect_str += f", weights = {weights}"
        if not weights in data_for_model:
            raise ValueError(f"Key '{weights}' not found in data")
        
    if 'scale.model' in effect_details:
        scaling = effect_details['scale.model']
        scaling = "TRUE" if scaling else "FALSE"
        random_effect_str += f", scale.model = {scaling}"

    if 'adjust_for_con_comp' in effect_details:
        con_comp = effect_details['adjust_for_con_comp']
        con_comp = "TRUE" if con_comp else "FALSE"
        random_effect_str += f", adjust.for.con.comp = {con_comp}"

    target_keys = ['graph']
    Cmatrixs_key = None

    for key in effect_details:
        if key in target_keys:
            Cmatrixs_key = effect_details[key]
            break

    if Cmatrixs_key is not None:
        random_effect_str += f", graph = {Cmatrixs_key}"
        if not Cmatrixs_key in graph_data:
            raise ValueError(f"Key '{Cmatrixs_key}' not found in graph_data")
    
    return random_effect_str

def latent_field_bym2(effect_details, random_effect_str, data_for_model, graph_data):
    """Create a string snippet for additional parameters"""

    if 'hyper' in effect_details:
        hyper = effect_details['hyper']
        hyper_str = create_hyper_string_fixed(hyper)
        random_effect_str += f", hyper = {hyper_str}"

    if 'weights' in effect_details:
        weights = effect_details['weights']
        random_effect_str += f", weights = {weights}"

    if 'scale.model' in effect_details:
        scaling = effect_details['scale.model']
        scaling = "TRUE" if scaling else "FALSE"
        random_effect_str += f", scale.model = {scaling}"

    if 'adjust_for_con_comp' in effect_details:
        con_comp = effect_details['adjust_for_con_comp']
        con_comp = "TRUE" if con_comp else "FALSE"
        random_effect_str += f", adjust.for.con.comp = {con_comp}"

    target_keys = ['graph']
    Cmatrixs_key = None

    for key in effect_details:
        if key in target_keys:
            Cmatrixs_key = effect_details[key]
            break

    if Cmatrixs_key is not None:
        random_effect_str += f", graph = {Cmatrixs_key}"
        if not Cmatrixs_key in graph_data:
            raise ValueError(f"Key '{Cmatrixs_key}' not found in graph_data")
    
    return random_effect_str

def create_random_effect_string(effect_name, effect_details, data_for_model, graph_data):

    if not 'id' in effect_details:
        raise ValueError(f"Key id is missing in the formula")

    id = effect_details['id']
    if not id in data_for_model:
        raise ValueError(f"Key '{id}' not found in data")

    model = effect_details.get('model', 'iid')
    if model not in ['iid', 'rw1', 'besag', 'bym', 'bym2']:
        return "Error: Model type is not supported."
    random_effect_str = f"f({id}, model = \"{model}\""
    if model == 'iid':
        random_effect_str = latent_field_iid(effect_details, random_effect_str, data_for_model)  # Update from return value
    elif model == 'rw1':
        random_effect_str = latent_field_rw1(effect_details, random_effect_str, data_for_model)
    elif model == 'besag':
        random_effect_str = latent_field_besag(effect_details, random_effect_str, data_for_model, graph_data)
    elif model == 'bym':
        random_effect_str = latent_field_bym(effect_details, random_effect_str, data_for_model, graph_data)
    elif model == 'bym2':
        random_effect_str = latent_field_bym2(effect_details, random_effect_str, data_for_model, graph_data)
    random_effect_str += ")"
    return random_effect_str

def make_full(i, j, x):
    is_lower_triangular = np.all(i >= j)
    is_upper_triangular = np.all(i <= j)

    if is_lower_triangular or is_upper_triangular:
        mask = i != j 
        i_new = np.concatenate([i, j[mask]])
        j_new = np.concatenate([j, i[mask]])
        x_new = np.concatenate([x, x[mask]])
        return i_new, j_new, x_new
    else:
        return i, j, x  
    
def convert_to_sparse_matrix(graph_data):
    pandas2ri.activate()
    numpy2ri.activate()
    graphs = {}

    for key, df in graph_data.items():
        i = df['i']
        j = df['j']        
        
        i_full, j_full, x_full = make_full(i, j, np.ones(len(i), dtype=int))

        i = robjects.IntVector(i_full)
        j = robjects.IntVector(j_full)
        x_r = numpy2ri.py2rpy(x_full)
        n = max(max(i_full), max(j_full))  
        Q_sparse = RMatrix.sparseMatrix(i=i, j=j, x=x_r, dims=robjects.IntVector([n, n]))
        graphs[key] = inla_read_graph(Q_sparse)

    pandas2ri.deactivate()
    numpy2ri.deactivate()
    return(graphs)   

def separate_graph_dataframes(data):
    non_graph_data = {}
    graph_data = {}
    for key, value in data.items():
        if isinstance(value, pd.DataFrame) and 'i' in value.columns and 'j' in value.columns:
            graph_data[key] = value
        else:
            non_graph_data[key] = value
    return non_graph_data, graph_data


def formula_from_dict(variables_dict, data_for_model, graph_data):
    terms = []

    response = variables_dict.get('response', None)

    if not response:
        raise ValueError("Response variable must be provided.")
    if response not in data_for_model:
        raise ValueError(f"Data for response variable '{response}' is missing.")

    intercept_value = variables_dict.get('intercept', 1)
    if intercept_value not in [1, -1]:
        raise ValueError("Intercept can only be 1 or -1.")
    if intercept_value == 1:
        terms.append("1")  # Adding an explicit intercept term if it's 1
    else:
        terms.append("-1")  # If it's -1, it means no intercept in the formula


    variables_dict = handle_fixed_effects(variables_dict)
    fixed = variables_dict.get('fixed', [])

    if isinstance(fixed, str):
        fixed = [fixed]  

    for fixed_effect in fixed:
        if not isinstance(fixed_effect, str):
            raise ValueError("Fixed effects must be a list of strings or a single string.")

        if fixed_effect not in data_for_model:
            raise ValueError(f"Data for fixed effect '{fixed_effect}' is missing.")

        fixed_modified = fixed.copy()
        if isinstance(data_for_model[fixed_effect], pd.DataFrame):
            df = data_for_model.pop(fixed_effect)  
            column_vectors = convert_dataframe_to_r_vectors(df)
            data_for_model.update(column_vectors)  

            fixed_modified.remove(fixed_effect)  
            fixed_modified.extend(df.columns)  
        fixed = fixed_modified

    terms.extend(fixed)
    for key, value in list(data_for_model.items()): 
        if isinstance(value, pd.DataFrame):
            df = data_for_model.pop(key)  
            column_vectors = convert_dataframe_to_r_vectors(df)
            data_for_model.update(column_vectors)  

    if 'random' in variables_dict:
        random_effects = variables_dict['random']
        if isinstance(random_effects, dict):
            for effect_name, effect_details in random_effects.items():
                if isinstance(effect_details, dict):
                    terms.append(create_random_effect_string(effect_name, effect_details, data_for_model, graph_data))
                else:
                    raise TypeError(f"Expected a dictionary for random effect details, got {type(effect_details)}")
        else:
            raise TypeError(f"Expected a dictionary for random effects, got {type(random_effects)}")


    formula_string = f"{response} ~ " + ' + '.join(map(str, terms))
    return formula(formula_string)
