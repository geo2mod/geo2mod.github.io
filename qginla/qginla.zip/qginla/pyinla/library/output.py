# -------------------------------------------------------------------
# File: output.py
# Author: Esmail Abdul Fattah
# Email: esmail@r-inla.org
# 
# Copyright (c) 2024 [Esmail Abdul Fattah]. All rights reserved.
# 
# This code is intended solely for use in the QGINLA project. 
# Unauthorized copying, editing, or distribution of this file, 
# via any medium, is strictly prohibited without prior written
# permission from the author.
# -------------------------------------------------------------------


from qginla.pyinla.library.utils import *


def get_marginals_fixed(name, object, inla_dict):

    inla_dict[name] = {}
    name_R = StrVector([name])
    x = object.rx[name_R][0]
    if isinstance(x, NULLType):
        return 
    x_names = x.names
    df = object.rx2(name_R)

    for i in range(len(x_names)):
        x_names[i] = 'intercept' if str(x_names[i]) == '(Intercept)' else x_names[i]
        if not isinstance(df[i], NULLType):
            inla_dict[name][str(x_names[i])] = pd.DataFrame(df[i], columns=["x", "y"])


def get_marginals_random(name, object, inla_dict):
    inla_dict[name] = {}
    name_R = StrVector([name])
    x = object.rx[name_R][0]
    if isinstance(x, NULLType):
        return 
    marginals_random = object.rx2(name_R)
    for col_name in marginals_random.names:
        inla_dict[name][str(col_name)] = {}
        r_col_name = StrVector([col_name])
        r_data = marginals_random.rx2(r_col_name)  # Accessing R object elements by name
        for id_name in r_data.names:
            inla_dict[name][str(col_name)][str(id_name)] = {}
            r_id_name = StrVector([id_name])
            id_r_data = r_data.rx2(r_id_name)  # Accessing R object elements by name
            inla_dict[name][str(col_name)][str(id_name)] = pd.DataFrame(id_r_data, columns=["x", "y"])

def get_marginals_linear_predictor(name, object, inla_dict):

    inla_dict[name] = {}
    name_R = StrVector([name])
    x = object.rx[name_R][0]
    if isinstance(x, NULLType):
        return 
    x_names = x.names
    df = object.rx2(name_R)
    if len(df) == 0:
        return
    for i in range(len(x_names)):
        if not isinstance(df[i], NULLType):
            inla_dict[name][str(x_names[i])] = pd.DataFrame(df[i], columns=["x", "y"])

def get_marginals_fitted_values(name, object, inla_dict):

    inla_dict[name] = {}
    name_R = StrVector([name])
    x = object.rx[name_R][0]
    if isinstance(x, NULLType):
        return 
    x_names = x.names
    df = object.rx2(name_R)
    if len(df) == 0:
        return
    for i in range(len(x_names)):
        if not isinstance(df[i], NULLType):
            inla_dict[name][str(x_names[i])] = pd.DataFrame(df[i], columns=["x", "y"])

def get_residuals(name, object, inla_dict):

    inla_dict[name] = {}
    name_R = StrVector([name])
    x = object.rx[name_R][0]
    if isinstance(x, NULLType):
        return 
    x_names = x.names
    df = object.rx2(name_R)
    for i in range(len(x_names)):
        if not isinstance(df[i], NULLType):
            inla_dict[name][str(x_names[i])] = pd.DataFrame(df[i])

def get_marginals_hyperpar(name, object, inla_dict):

    inla_dict[name] = {}
    name_R = StrVector([name])
    x = object.rx[name_R][0]
    if isinstance(x, NULLType):
        return 
    x_names = x.names
    df = object.rx2(name_R)
    if len(df) == 0:
        return
    for i in range(len(x_names)):
        if not isinstance(df[i], NULLType):
            inla_dict[name][str(x_names[i])] = pd.DataFrame(df[i], columns=["x", "y"])

def get_summary_fixed(name, object, inla_dict):
    
    name_R = StrVector([name])
    x = object.rx[name_R][0]
    if isinstance(x, NULLType):
        return 
    summary_fixed = object.rx2(name_R)
    if len(summary_fixed) == 0:
        return
    df = pd.DataFrame(summary_fixed)
    column_names = {}
    row_names = {}

    if hasattr(x, 'colnames'):
        if x.colnames is not None:
            column_names = list(x.colnames)
            df.index = column_names
    if hasattr(x, 'rownames'):
        if x.rownames is not None:
            row_names = list(x.rownames)
            df.columns = row_names

    df.columns = ['intercept' if index == '(Intercept)' else index for index in df.columns]
    inla_dict[name] = df


def get_summary_random(name, object, inla_dict):
    
    name_R = StrVector([name])
    x = object.rx[name_R][0]
    if isinstance(x, NULLType):
        return 
    summary_random = object.rx2(name_R)
    if len(summary_random) == 0:
        return

    inla_dict[name] = {}
    for col_name in summary_random.names:
        r_col_name = StrVector([col_name])
        r_data = summary_random.rx2(r_col_name)  # Accessing R object elements by name
        df = pd.DataFrame(r_data)
        column_names = {}
        row_names = {}
        inla_dict[name][col_name] = {}
        if hasattr(r_data, 'colnames'):
            if r_data.colnames is not None:
                column_names = list(r_data.colnames)
                df.index = column_names
        if hasattr(r_data, 'rownames'):
            if r_data.rownames is not None:
                row_names = list(r_data.rownames)
                df.columns = row_names
        inla_dict[name][col_name] = df


def get_summary_hyperpar(name, object, inla_dict):
    
    name_R = StrVector([name])
    x = object.rx[name_R][0]
    if isinstance(x, NULLType):
        return 
    summary_hyperpar = object.rx2(name_R)
    if len(summary_hyperpar) == 0:
        return
    df = pd.DataFrame(summary_hyperpar)

    column_names = {}
    row_names = {}

    if hasattr(x, 'colnames'):
        if x.colnames is not None:
            column_names = list(x.colnames)
            df.index = column_names
    if hasattr(x, 'rownames'):
        if x.rownames is not None:
            row_names = list(x.rownames)
            df.columns = row_names

    inla_dict[name] = df

def get_summary_fitted_values(name, object, inla_dict):
    
    name_R = StrVector([name])
    x = object.rx[name_R][0]
    if isinstance(x, NULLType):
        return 
    summary_fitted_values = object.rx2(name_R)
    if len(summary_fitted_values) == 0:
        return
    df = pd.DataFrame(summary_fitted_values)

    column_names = {}
    row_names = {}
    if hasattr(x, 'colnames'):
        if x.colnames is not None:
            column_names = list(x.colnames)
            df.index = column_names
    if hasattr(x, 'rownames'):
        if x.rownames is not None:
            row_names = list(x.rownames)
            df.columns = row_names

    inla_dict[name] = df

def get_summary_linear_predictor(name, object, inla_dict):
    
    name_R = StrVector([name])
    x = object.rx[name_R][0]
    if isinstance(x, NULLType):
        return 
    summary_linear_predictor = object.rx2(name_R)
    if len(summary_linear_predictor) == 0:
        return
    df = pd.DataFrame(summary_linear_predictor)

    column_names = {}
    row_names = {}

    if hasattr(x, 'colnames'):
        if x.colnames is not None:
            column_names = list(x.colnames)
            df.index = column_names
    if hasattr(x, 'rownames'):
        if x.rownames is not None:
            row_names = list(x.rownames)
            df.columns = row_names

    inla_dict[name] = df

def get_cpo(inla_dict, name, x):
    inla_dict[name] = {}
    if isinstance(x, NULLType):
        return 

    for col_name in x.names:
        r_col_name = StrVector([col_name])

        r_data = x.rx2(r_col_name)  # Accessing R object elements by name
        if isinstance(r_data, NULLType):
            inla_dict[name][col_name] = None  # Handle NULL values in R
        else:
            inla_dict[name][col_name] = np.array(r_data) 

def get_waic(inla_dict, name, x):
    inla_dict[name] = {}
    if isinstance(x, NULLType):
        return 
    for col_name in x.names:
        r_col_name = StrVector([col_name])

        r_data = x.rx2(r_col_name)  # Accessing R object elements by name
        if isinstance(r_data, NULLType):
            inla_dict[name][col_name] = None  # Handle NULL values in R
        else:
            inla_dict[name][col_name] = np.array(r_data) 


def get_dic(inla_dict, name, x):
    inla_dict[name] = {}
    if isinstance(x, NULLType):
        return 
    for col_name in x.names:
        r_col_name = StrVector([col_name])
        
        r_data = x.rx2(r_col_name)  # Accessing R object elements by name
        if isinstance(r_data, NULLType):
            inla_dict[name][col_name] = None  # Handle NULL values in R
        else:
            inla_dict[name][col_name] = np.array(r_data) 

def get_gcpo(inla_dict, name, x):
    inla_dict[name] = {}
    if isinstance(x, NULLType):
        return 
    for col_name in x.names:
        r_col_name = StrVector([col_name])
        r_data = x.rx2(r_col_name)  # Accessing R object elements by name
        
        if isinstance(r_data, NULLType):
            inla_dict[name][col_name] = None  # Handle NULL values in R
        else:
            inla_dict[name][col_name] = np.array(r_data) 

def get_mlik(object, inla_dict, name):

    name_R = StrVector([name])
    x = object.rx[name_R]
    if isinstance(x, NULLType):
        return 
    inla_dict[name] = {}
    df = pd.DataFrame(x[0])
    inla_dict[name] = df
    df.index = ['log marginal-likelihood (integration)', 'log marginal-likelihood (Gaussian)']
  
def get_cpuused(object, inla_dict, name):

    name_R = StrVector([name])
    x = object.rx[name_R]
    if isinstance(x, NULLType):
        return 
    inla_dict[name] = {}
    df = pd.DataFrame(x)
    df.columns = ['Pre', 'Running', 'Post', 'Total']
    inla_dict[name] = df


def replace_dots_with_underscores(data):
    new_data = {}
    for key, value in data.items():
        new_key = key.replace('.', '_')
        if isinstance(value, dict):
            new_data[new_key] = replace_dots_with_underscores(value)
        else:
            new_data[new_key] = value

    return new_data


