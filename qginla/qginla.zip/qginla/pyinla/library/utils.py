# -------------------------------------------------------------------
# File: utils.py
# Author: Esmail Abdul Fattah
# Email: esmail@r-inla.org
# 
# Copyright (c) 2024 [Esmail Abdul Fattah]. All rights reserved.
# 
# This code is intended solely for use in the QGINLA project. 
# Unauthorized copying, editing, or distribution of this file, 
# via any medium, is strictly prohibited without prior written
# permission from the author.
# -------------------------------------------------------------------


import time
import sys
import os
import numpy as np
import pandas as pd
import json

from rpy2.robjects.packages import importr
from rpy2.robjects.vectors import DataFrame, ListVector, FloatVector, IntVector, Matrix, StrVector, FloatMatrix, BoolVector
from rpy2.rinterface_lib.sexp import NULLType
from rpy2.robjects import Formula
from rpy2.robjects.functions import SignatureTranslatedFunction
from rpy2.robjects.environments import Environment
from rpy2.robjects.methods import RS4
from rpy2.robjects import pandas2ri
from rpy2.robjects import r
import rpy2.robjects as robjects
import rpy2.rinterface_lib.sexp
import subprocess
from rpy2.robjects import numpy2ri


robjects.r('suppressPackageStartupMessages(library(INLA))')
robjects.r('suppressPackageStartupMessages(library(Matrix))')

call = importr('INLA', lib_loc=robjects.r('find.package("INLA")')[0][:-5])
RMatrix = importr('Matrix', lib_loc=robjects.r('find.package("Matrix")')[0][:-7])
inla_read_graph = robjects.r('INLA:::inla.read.graph')


def get_inla_version():
    inla_path = robjects.r('find.package("INLA")')[0]
    description_file_path = os.path.join(inla_path, 'DESCRIPTION')

    try:
        with open(description_file_path, 'r') as file:
            for line in file:
                if line.startswith("Built"):
                    return(line.strip())  # Print only the version line
                    break
    except FileNotFoundError:
        print(f"DESCRIPTION file not found in the INLA package directory: {description_file_path}")


def create_hyper_string(hyper):
    """Helper function to create the string for hyperparameters"""
    hyper_parts = []
    for key, value in hyper.items():
        if isinstance(value, dict):
            # Nested dictionary, format as a nested list
            nested_str = create_hyper_string(value)
            hyper_parts.append(f"{key} = list({nested_str})")
        elif isinstance(value, list):
            # List of parameters, format as a vector
            list_str = ", ".join([format_prior_name(v) if key == 'prior' else str(v) for v in value])
            hyper_parts.append(f"{key} = c({list_str})")
        else:
            # Single value
            formatted_value = format_prior_name(value) if key == 'prior' else value
            hyper_parts.append(f"{key} = \"{formatted_value}\"")

    return "list(" + ", ".join(hyper_parts) + ")"

def format_prior_name(prior_name):
    """Helper function to format the prior name, replacing underscores with periods"""
    if isinstance(prior_name, str):
        return prior_name.replace('_', '.')
    return prior_name














