from qgis.PyQt.QtCore import *
from qgis.PyQt.QtWidgets import QToolButton, QAction, QSizePolicy, QProgressBar
from qgis.core import Qgis,QgsProject
from qgis.utils import iface
from typing import Optional
import time
import os
import os.path as op
from qgis.core import QgsVectorLayer
import tempfile
import platform
import subprocess
import sys
from typing import Optional
from ctypes import cdll
from qgis.PyQt.QtCore import QCoreApplication
from qgis.core import (Qgis,
                       QgsVectorFileWriter
)
from processing.core.ProcessingConfig import ProcessingConfig
from processing.tools.system import userFolder, mkdir
import rpy2.robjects.packages as rpackages
from sklearn.preprocessing import scale, MinMaxScaler
#import geopandas as gpd
import pandas as pd
#from libpysal.weights import Rook
from qginla.pyinla.library.inla import inla
import numpy as np
import fiona
from shapely.wkt import dumps
from shapely.geometry import shape
import networkx as nx


class pyinla_utils:
    """Some useful functions for QGINLA"""



    # @staticmethod
    # def import_vector(path) -> tuple:
    #     """Import vector as QgsVectorLayer"""

    #     if not os.path.exists(path):
    #         raise Exception("Cannot find file '" + path + "'.")

    #     try:
    #         # read the shapefile as a GeoDataFrame
    #         gdf = gpd.read_file(path)

    #         vlayer=QgsVectorLayer(path, os.path.splitext(op.basename(path))[0], 'ogr')
    #         metadata = {'crs': vlayer.sourceCrs(), 'extent': vlayer.sourceExtent}

    #         return gdf, vlayer, metadata

    #     except Exception as e:
    #         raise Exception(str(e))

 

    def to_scale(df,columns_to_scale, scale_method) -> pd.DataFrame:
        """Scale covariates"""

        if scale_method=='zero':
            # Scale the dataframe columns
            df[columns_to_scale]=scale(df[columns_to_scale])
            return(df)
        elif scale_method=='minmax':
            df[columns_to_scale]=MinMaxScaler().fit_transform(df[columns_to_scale])
            return(df)
        else:
            return(df)

    def to_drop_nan(df,columns_to_check) -> pd.DataFrame:
        """Drop rows with NaN value"""

        df.dropna(subset=columns_to_check)
        return df

    def ID_generator(df) -> pd.DataFrame:
        """Generate column ID"""

        df.insert(0, 'ID_code', range(1, len(df)+1))
        IDcolumn='ID_code'
        return(df,IDcolumn)

    # @staticmethod
    # def graph_ID_generator(df) -> pd.DataFrame:
    #     df.insert(0, 'ID_unstruc', range(1, len(df)+1))
    #     IDcolumn='ID_unstruc'
    #     return(df,IDcolumn)

    # def graph_calculator(gdf,idcolumn):
    #     """Build graph object"""

    #     w_rook = Rook.from_dataframe(gdf,ids=idcolumn)
    #     output_file = op.join(tempfile.gettempdir(), 'graph.adj')
    #     with open(output_file, 'w') as f:
    #         f.write(f"{len(w_rook.neighbors.items())}\n")
    #         for node, neighbors in w_rook.neighbors.items():
    #             neighbors.sort()
    #             num=len([str(int(num)) for num in neighbors])
    #             numbers_str = f"{int(node)}"+" "+str(num)+" "+(' '.join(str(int(num)) for num in neighbors))
    #             line = f"{numbers_str}\n"
    #             if len(numbers_str)==0:
    #                 continue
    #             else:
    #                 f.write(line)
    #     return output_file
    # def graph_calculator(gdf, idcolumn):
    #     """Build graph object using geopandas and networkx."""
        
    #     # Create a graph
    #     G = nx.Graph()
        
    #     # Add nodes
    #     for i, row in gdf.iterrows():
    #         G.add_node(row[idcolumn])
        
    #     # Add edges based on Rook contiguity
    #     for i, row1 in gdf.iterrows():
    #         for j, row2 in gdf.iterrows():
    #             if i == j:
    #                 continue  # Skip self-comparison
    #             if row1.geometry.touches(row2.geometry):
    #                 G.add_edge(row1[idcolumn], row2[idcolumn])
        
    #     # Write the graph to a file
    #     output_file = os.path.join(tempfile.gettempdir(), 'graph.adj')
    #     with open(output_file, 'w') as f:
    #         f.write(f"{len(G.nodes)}\n")
    #         for node in G.nodes:
    #             neighbors = sorted(G.neighbors(node))
    #             num_neighbors = len(neighbors)
    #             if num_neighbors == 0:
    #                 continue
    #             line = f"{int(node)} {num_neighbors} {' '.join(map(str, neighbors))}\n"
    #             f.write(line)
        
    #     return output_file
    def graph_calculator(gpkg_path, idcolumn):
        
        # Read features from the GeoPackage
        geometries = []
        ids = []
        with fiona.open(gpkg_path, layer='') as src:
            id=0
            for feature in src:
                geom = shape(feature['geometry'])
                geometries.append(geom)
                ids.append(id)
                id+=1
        
        # Create graph
        G = nx.Graph()
        
        # Add nodes
        for node_id in ids:
            G.add_node(node_id)
        
        # Add edges based on Rook contiguity (shared boundaries)
        for i, geom1 in enumerate(geometries):
            for j in range(i + 1, len(geometries)):  # Avoid redundant checks
                geom2 = geometries[j]
                if geom1.touches(geom2):  # Check for shared boundaries
                    G.add_edge(ids[i], ids[j])
        
        # Write the graph to a file
        output_file = os.path.join(tempfile.gettempdir(), 'graph.adj')
        with open(output_file, 'w') as f:
            f.write(f"{len(G.nodes)}\n")
            for node in G.nodes:
                neighbors = sorted(G.neighbors(node))
                num_neighbors = len(neighbors)
                if num_neighbors == 0:
                    continue
                line = f"{node} {num_neighbors} {' '.join(map(str, neighbors))}\n"
                f.write(line)
        
        return output_file
    
    def find_key(dictionary, target_value):
        """List parameters"""
        for key, value in dictionary.items():
            if value == target_value:
                return True
            elif isinstance(value, dict):
                nested_result = pyinla_utils.find_key(value, target_value)
                if nested_result:
                    return True
        return False


    def type_constructor(var,type,prior,hyp1,hyp2,graph,ID=None,hyp3=None,hyp4=None):
        if type=='iid':
            prec_prior = {'prec': {'prior': prior, 'param': [hyp1, hyp2]}}#[1, 0.001]
            random_eff = {'id':var,
                        'model': 'iid',
                        'hyper': prec_prior}
        
        if type=='rw1':
            prec_prior = {'theta': {'prior': prior, 'param': [hyp1, hyp2]}}#[1, 0.01]
            random_eff = {'id':var, 
                        'model': 'rw1', 
                        'scale.model': True, 
                        'hyper': prec_prior}
            
        if type=='besag':
            prec_prior = {'prec': {'prior': prior, 'param': [hyp1, hyp2]}}#[4, 0.005]
            random_eff = {'id':ID, 
                        'model': 'besag', 
                        'scale.model': True, 
                        'adjust.for.con.comp': True , 
                        'graph': graph,
                        'hyper': prec_prior}
            
        if type=='bym':
            prec_prior = {'prec.unstruct': {'prior': prior, 'param': [hyp1, hyp2]}, 'prec.spatial': {'prior': 'loggamma', 'param': [hyp3, hyp4]}}#[1, 0.005]/[1, 0.001] ask for prec.spatial prior
            random_eff = {'id':ID, 
                        'model': 'bym', 
                        'scale.model': True, 
                        'adjust.for.con.comp': True , 
                        'graph': graph,
                        'hyper': prec_prior}
            
        if type=='bym2':
            prec_prior = {'prec': {'prior': prior, 'param': [hyp1, hyp2], 'initial': [5]}, 'phi': {'prior': 'pc', 'param': [hyp3, hyp4], 'initial':[-3]}}#[1.61290322580645,0.01]/[0.5, 0.5] ask for phi prior
            random_eff = {'id':ID, 
                        'model': 'bym2', 
                        'scale.model': True, 
                        'adjust.for.con.comp': True ,
                        'graph': graph,
                        'hyper': prec_prior}
        
        if type=='Siid':
            prec_prior = {'prec': {'prior': prior, 'param': [hyp1, hyp2]}}#[1, 0.001]
            random_eff = {'id':ID,
                        'model': 'iid',
                        'hyper': prec_prior}
            

        return random_eff
    
    def inla_call(df,family,formula,ntrials):
        print('formula',formula)
        
        #gaussian
        if family=="gaussian":
            inference = inla(formula=formula,
                    data=df, 
                    family="gaussian", 
                    verbose=False, 
                    control_predictor = {'compute': True},
                    control_fixed = {'mean.intercept': 0, 'prec':1},
                    control_compute = {'return.marginals.predictor': True, 'cpo': True, 'dic': True, 'waic': True},
                )

        # poisson
        if family=="poisson":
            inference = inla(formula=formula,
                            data=df, 
                            family="poisson", 
                            verbose=False, 
                            control_predictor = {'compute': True},
                            control_fixed = {'mean.intercept': 0, 'prec':1},
                            control_compute = {'return.marginals.predictor': True, 'cpo': True, 'dic': True, 'waic': True},
                        )

        #binomial
        if family=="binomial":
            inference = inla(formula=formula,
                            data=df, 
                            family="binomial", 
                            verbose=False, 
                            Ntrials = ntrials,
                            control_predictor = {'compute': True},
                            control_fixed = {'mean.intercept': 0, 'prec':1},
                            control_compute = {'return.marginals.predictor': True, 'cpo': True, 'dic': True, 'waic': True},
                        )
        return inference

    def merge_dataframes(ID, table, gdf):

        df=table.transpose()
        df[ID] = range(len(df))


        """Reconstruct the geometries of input vector"""
        columnnames=df.columns.tolist()
        #columnnames=columnnames[1:]
        columnnames.append('geom')
        columnnames.append(ID)
        df[ID]=list(gdf[ID])
        gdf_merged = gdf.merge(df, on=ID)
        gdf_merged=gdf_merged[columnnames]
        return gdf_merged